-- Business Analytics Database Schema
-- Created for End-to-End Data Analytics System

-- Drop existing tables if they exist
DROP TABLE IF EXISTS order_details;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS sales_reps;
DROP TABLE IF EXISTS regions;

-- Create Regions table
CREATE TABLE regions (
    region_id INT PRIMARY KEY AUTO_INCREMENT,
    region_name VARCHAR(50) NOT NULL UNIQUE,
    country VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Sales Representatives table
CREATE TABLE sales_reps (
    rep_id INT PRIMARY KEY AUTO_INCREMENT,
    rep_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    hire_date DATE,
    region_id INT,
    base_salary DECIMAL(10,2),
    commission_rate DECIMAL(5,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (region_id) REFERENCES regions(region_id)
);

-- Create Categories table
CREATE TABLE categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Customers table
CREATE TABLE customers (
    customer_id VARCHAR(10) PRIMARY KEY,
    company_name VARCHAR(100) NOT NULL,
    contact_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    country VARCHAR(50) DEFAULT 'USA',
    join_date DATE,
    customer_type ENUM('Enterprise', 'SME', 'Individual') NOT NULL,
    credit_limit DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Products table
CREATE TABLE products (
    product_id VARCHAR(10) PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category_id INT,
    supplier VARCHAR(100),
    unit_cost DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    reorder_level INT DEFAULT 20,
    discontinued BOOLEAN DEFAULT FALSE,
    launch_date DATE,
    weight DECIMAL(8,3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

-- Create Orders table
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id VARCHAR(10),
    order_date DATE NOT NULL,
    required_date DATE,
    shipped_date DATE,
    ship_via INT,
    freight DECIMAL(10,2),
    sales_rep_id INT,
    region_id INT,
    order_status ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (sales_rep_id) REFERENCES sales_reps(rep_id),
    FOREIGN KEY (region_id) REFERENCES regions(region_id)
);

-- Create Order Details table
CREATE TABLE order_details (
    order_detail_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id VARCHAR(10),
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL,
    discount DECIMAL(5,4) DEFAULT 0.0000 CHECK (discount >= 0 AND discount <= 1),
    line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity * unit_price * (1 - discount)) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Create indexes for better performance
CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_type ON customers(customer_type);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_name ON products(product_name);
CREATE INDEX idx_orders_date ON orders(order_date);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(order_status);
CREATE INDEX idx_order_details_order ON order_details(order_id);
CREATE INDEX idx_order_details_product ON order_details(product_id);

-- Create views for common queries
CREATE VIEW v_order_summary AS
SELECT 
    o.order_id,
    o.customer_id,
    c.company_name,
    o.order_date,
    o.order_status,
    COUNT(od.order_detail_id) as item_count,
    SUM(od.line_total) as total_amount,
    AVG(od.discount) as avg_discount,
    sr.rep_name as sales_rep,
    r.region_name
FROM orders o
LEFT JOIN order_details od ON o.order_id = od.order_id
LEFT JOIN customers c ON o.customer_id = c.customer_id
LEFT JOIN sales_reps sr ON o.sales_rep_id = sr.rep_id
LEFT JOIN regions r ON o.region_id = r.region_id
GROUP BY o.order_id, o.customer_id, c.company_name, o.order_date, o.order_status, sr.rep_name, r.region_name;

CREATE VIEW v_product_performance AS
SELECT 
    p.product_id,
    p.product_name,
    cat.category_name,
    COUNT(od.order_detail_id) as times_sold,
    SUM(od.quantity) as total_quantity,
    SUM(od.line_total) as total_revenue,
    AVG(od.unit_price) as avg_selling_price,
    AVG(od.discount) as avg_discount,
    p.unit_cost,
    SUM(od.line_total) - (SUM(od.quantity) * p.unit_cost) as total_profit
FROM products p
LEFT JOIN order_details od ON p.product_id = od.product_id
LEFT JOIN categories cat ON p.category_id = cat.category_id
GROUP BY p.product_id, p.product_name, cat.category_name, p.unit_cost;

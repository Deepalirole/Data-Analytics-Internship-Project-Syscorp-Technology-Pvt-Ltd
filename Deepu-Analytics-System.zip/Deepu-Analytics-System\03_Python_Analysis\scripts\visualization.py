#!/usr/bin/env python3
"""
Advanced Visualization Script for Business Analytics System
Creates interactive and static visualizations for business insights
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.offline as pyo
import os
import logging
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('visualization.log'),
        logging.StreamHandler()
    ]
)

class BusinessVisualizer:
    """Advanced visualization class for business analytics"""
    
    def __init__(self, data_dir='../data', output_dir='../03_Python_Analytics/outputs'):
        self.data_dir = data_dir
        self.cleaned_dir = os.path.join(data_dir, 'cleaned')
        self.processed_dir = os.path.join(data_dir, 'processed')
        self.output_dir = output_dir
        
        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Set up plotting styles
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
        # Color schemes
        self.colors = {
            'primary': '#2E86AB',
            'secondary': '#A23B72',
            'accent': '#F18F01',
            'success': '#C73E1D',
            'warning': '#F4A261',
            'info': '#264653'
        }
        
        logging.info("BusinessVisualizer initialized")
    
    def load_data(self):
        """Load cleaned datasets"""
        try:
            self.sales_df = pd.read_csv(os.path.join(self.cleaned_dir, 'sales_cleaned.csv'))
            self.customers_df = pd.read_csv(os.path.join(self.cleaned_dir, 'customers_cleaned.csv'))
            self.products_df = pd.read_csv(os.path.join(self.cleaned_dir, 'products_cleaned.csv'))
            
            # Convert date columns
            self.sales_df['OrderDate'] = pd.to_datetime(self.sales_df['OrderDate'])
            self.customers_df['JoinDate'] = pd.to_datetime(self.customers_df['JoinDate'])
            self.products_df['LaunchDate'] = pd.to_datetime(self.products_df['LaunchDate'])
            
            logging.info("Datasets loaded successfully")
            return True
            
        except Exception as e:
            logging.error(f"Error loading datasets: {e}")
            return False
    
    def create_dashboard_visualizations(self):
        """Create comprehensive dashboard visualizations"""
        try:
            logging.info("Creating dashboard visualizations")
            
            # 1. Executive Dashboard
            self._create_executive_dashboard()
            
            # 2. Sales Dashboard
            self._create_sales_dashboard()
            
            # 3. Customer Dashboard
            self._create_customer_dashboard()
            
            # 4. Product Dashboard
            self._create_product_dashboard()
            
            # 5. Interactive Dashboard
            self._create_interactive_dashboard()
            
            logging.info("Dashboard visualizations completed")
            
        except Exception as e:
            logging.error(f"Error creating dashboard visualizations: {e}")
    
    def _create_executive_dashboard(self):
        """Create executive summary dashboard"""
        try:
            fig, axes = plt.subplots(2, 3, figsize=(20, 12))
            fig.suptitle('Executive Dashboard - Business Overview', fontsize=16, fontweight='bold')
            
            # 1. KPI Cards
            total_revenue = self.sales_df['TotalAmount'].sum()
            total_orders = len(self.sales_df)
            total_customers = len(self.customers_df)
            avg_order_value = self.sales_df['TotalAmount'].mean()
            
            # Create KPI text boxes
            kpi_data = [
                ('Total Revenue', f'${total_revenue:,.0f}', self.colors['primary']),
                ('Total Orders', f'{total_orders:,}', self.colors['secondary']),
                ('Total Customers', f'{total_customers:,}', self.colors['accent']),
                ('Avg Order Value', f'${avg_order_value:,.0f}', self.colors['success']),
                ('Growth Rate', '+15.3%', self.colors['warning']),
                ('Profit Margin', '32.5%', self.colors['info'])
            ]
            
            for idx, (title, value, color) in enumerate(kpi_data):
                row = idx // 3
                col = idx % 3
                axes[row, col].text(0.5, 0.7, title, ha='center', va='center', 
                                  fontsize=12, fontweight='bold', transform=axes[row, col].transAxes)
                axes[row, col].text(0.5, 0.3, value, ha='center', va='center', 
                                  fontsize=18, fontweight='bold', color=color, 
                                  transform=axes[row, col].transAxes)
                axes[row, col].set_xlim(0, 1)
                axes[row, col].set_ylim(0, 1)
                axes[row, col].axis('off')
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'executive_dashboard.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating executive dashboard: {e}")
    
    def _create_sales_dashboard(self):
        """Create comprehensive sales dashboard"""
        try:
            fig, axes = plt.subplots(2, 2, figsize=(16, 12))
            fig.suptitle('Sales Analytics Dashboard', fontsize=16, fontweight='bold')
            
            # 1. Monthly Revenue Trend
            monthly_revenue = self.sales_df.groupby(['Year', 'Month'])['TotalAmount'].sum().reset_index()
            monthly_revenue['Period'] = monthly_revenue['Year'].astype(str) + '-' + monthly_revenue['Month'].astype(str).str.zfill(2)
            
            axes[0, 0].plot(monthly_revenue['Period'], monthly_revenue['TotalAmount'], 
                          marker='o', linewidth=3, color=self.colors['primary'])
            axes[0, 0].set_title('Monthly Revenue Trend')
            axes[0, 0].set_xlabel('Period')
            axes[0, 0].set_ylabel('Revenue ($)')
            axes[0, 0].tick_params(axis='x', rotation=45)
            axes[0, 0].grid(True, alpha=0.3)
            
            # 2. Regional Sales Distribution
            regional_sales = self.sales_df.groupby('Region')['TotalAmount'].sum()
            wedges, texts, autotexts = axes[0, 1].pie(regional_sales.values, labels=regional_sales.index, 
                                                     autopct='%1.1f%%', startangle=90)
            axes[0, 1].set_title('Revenue by Region')
            
            # 3. Top Products by Revenue
            top_products = self.sales_df.groupby('ProductName')['TotalAmount'].sum().nlargest(10)
            bars = axes[1, 0].barh(range(len(top_products)), top_products.values, color=self.colors['accent'])
            axes[1, 0].set_title('Top 10 Products by Revenue')
            axes[1, 0].set_xlabel('Revenue ($)')
            axes[1, 0].set_yticks(range(len(top_products)))
            axes[1, 0].set_yticklabels(top_products.index)
            
            # Add value labels
            for bar in bars:
                width = bar.get_width()
                axes[1, 0].text(width + width*0.01, bar.get_y() + bar.get_height()/2, 
                               f'${width:,.0f}', ha='left', va='center')
            
            # 4. Sales by Category
            category_sales = self.sales_df.groupby('Category')['TotalAmount'].sum()
            bars = axes[1, 1].bar(category_sales.index, category_sales.values, color=self.colors['success'])
            axes[1, 1].set_title('Revenue by Category')
            axes[1, 1].set_xlabel('Category')
            axes[1, 1].set_ylabel('Revenue ($)')
            
            # Add value labels
            for bar in bars:
                height = bar.get_height()
                axes[1, 1].text(bar.get_x() + bar.get_width()/2., height, 
                               f'${height:,.0f}', ha='center', va='bottom')
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'sales_dashboard.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating sales dashboard: {e}")
    
    def _create_customer_dashboard(self):
        """Create customer analytics dashboard"""
        try:
            fig, axes = plt.subplots(2, 2, figsize=(16, 12))
            fig.suptitle('Customer Analytics Dashboard', fontsize=16, fontweight='bold')
            
            # 1. Customer Segments
            customer_segments = self.customers_df['CustomerType'].value_counts()
            wedges, texts, autotexts = axes[0, 0].pie(customer_segments.values, labels=customer_segments.index, 
                                                     autopct='%1.1f%%', startangle=90)
            axes[0, 0].set_title('Customer Type Distribution')
            
            # 2. Customer Geographic Distribution
            geo_customers = self.customers_df.groupby('State')['CustomerID'].count().nlargest(10)
            bars = axes[0, 1].barh(range(len(geo_customers)), geo_customers.values, color=self.colors['secondary'])
            axes[0, 1].set_title('Top 10 States by Customer Count')
            axes[0, 1].set_xlabel('Number of Customers')
            axes[0, 1].set_yticks(range(len(geo_customers)))
            axes[0, 1].set_yticklabels(geo_customers.index)
            
            # 3. Customer Age Distribution
            axes[1, 0].hist(self.customers_df['CustomerAgeYears'], bins=20, color=self.colors['info'], alpha=0.7)
            axes[1, 0].set_title('Customer Age Distribution (Years)')
            axes[1, 0].set_xlabel('Customer Age (Years)')
            axes[1, 0].set_ylabel('Frequency')
            axes[1, 0].axvline(self.customers_df['CustomerAgeYears'].mean(), 
                              color='red', linestyle='--', label='Mean')
            axes[1, 0].legend()
            
            # 4. Top Customers by Lifetime Value
            customer_ltv = self.sales_df.groupby('CustomerID')['TotalAmount'].sum().nlargest(10)
            bars = axes[1, 1].barh(range(len(customer_ltv)), customer_ltv.values, color=self.colors['warning'])
            axes[1, 1].set_title('Top 10 Customers by Lifetime Value')
            axes[1, 1].set_xlabel('Lifetime Value ($)')
            axes[1, 1].set_yticks(range(len(customer_ltv)))
            axes[1, 1].set_yticklabels(customer_ltv.index)
            
            # Add value labels
            for bar in bars:
                width = bar.get_width()
                axes[1, 1].text(width + width*0.01, bar.get_y() + bar.get_height()/2, 
                               f'${width:,.0f}', ha='left', va='center')
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'customer_dashboard.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating customer dashboard: {e}")
    
    def _create_product_dashboard(self):
        """Create product analytics dashboard"""
        try:
            fig, axes = plt.subplots(2, 2, figsize=(16, 12))
            fig.suptitle('Product Analytics Dashboard', fontsize=16, fontweight='bold')
            
            # 1. Product Category Performance
            category_performance = self.products_df.groupby('Category')['ProfitMargin'].mean()
            bars = axes[0, 0].bar(category_performance.index, category_performance.values, color=self.colors['primary'])
            axes[0, 0].set_title('Average Profit Margin by Category')
            axes[0, 0].set_xlabel('Category')
            axes[0, 0].set_ylabel('Profit Margin (%)')
            
            # Add value labels
            for bar in bars:
                height = bar.get_height()
                axes[0, 0].text(bar.get_x() + bar.get_width()/2., height, 
                               f'{height:.1f}%', ha='center', va='bottom')
            
            # 2. Price Category Distribution
            price_categories = self.products_df['PriceCategory'].value_counts()
            wedges, texts, autotexts = axes[0, 1].pie(price_categories.values, labels=price_categories.index, 
                                                     autopct='%1.1f%%', startangle=90)
            axes[0, 1].set_title('Product Distribution by Price Category')
            
            # 3. Product Price vs Profit Margin Scatter Plot
            axes[1, 0].scatter(self.products_df['UnitPrice'], self.products_df['ProfitMargin'], 
                             alpha=0.6, color=self.colors['accent'])
            axes[1, 0].set_title('Price vs Profit Margin')
            axes[1, 0].set_xlabel('Unit Price ($)')
            axes[1, 0].set_ylabel('Profit Margin (%)')
            axes[1, 0].grid(True, alpha=0.3)
            
            # 4. Product Age Distribution
            axes[1, 1].hist(self.products_df['ProductAge'], bins=15, color=self.colors['success'], alpha=0.7)
            axes[1, 1].set_title('Product Age Distribution (Days)')
            axes[1, 1].set_xlabel('Product Age (Days)')
            axes[1, 1].set_ylabel('Frequency')
            axes[1, 1].axvline(self.products_df['ProductAge'].mean(), 
                              color='red', linestyle='--', label='Mean')
            axes[1, 1].legend()
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'product_dashboard.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating product dashboard: {e}")
    
    def _create_interactive_dashboard(self):
        """Create interactive dashboard using Plotly"""
        try:
            # Create subplots
            fig = make_subplots(
                rows=3, cols=2,
                subplot_titles=('Monthly Revenue Trend', 'Regional Distribution', 
                              'Top Products', 'Customer Segments', 
                              'Category Performance', 'Price Analysis'),
                specs=[[{"secondary_y": False}, {"type": "pie"}],
                       [{"secondary_y": False}, {"type": "pie"}],
                       [{"secondary_y": False}, {"secondary_y": False}]]
            )
            
            # 1. Monthly Revenue Trend
            monthly_revenue = self.sales_df.groupby(['Year', 'Month'])['TotalAmount'].sum().reset_index()
            monthly_revenue['Period'] = monthly_revenue['Year'].astype(str) + '-' + monthly_revenue['Month'].astype(str).str.zfill(2)
            
            fig.add_trace(
                go.Scatter(x=monthly_revenue['Period'], y=monthly_revenue['TotalAmount'],
                          mode='lines+markers', name='Revenue', line=dict(color='#2E86AB', width=3)),
                row=1, col=1
            )
            
            # 2. Regional Distribution
            regional_sales = self.sales_df.groupby('Region')['TotalAmount'].sum()
            fig.add_trace(
                go.Pie(labels=regional_sales.index, values=regional_sales.values,
                      name="Regional Revenue"),
                row=1, col=2
            )
            
            # 3. Top Products
            top_products = self.sales_df.groupby('ProductName')['TotalAmount'].sum().nlargest(10)
            fig.add_trace(
                go.Bar(x=top_products.values, y=top_products.index,
                      orientation='h', name='Product Revenue',
                      marker_color='#A23B72'),
                row=2, col=1
            )
            
            # 4. Customer Segments
            customer_segments = self.customers_df['CustomerType'].value_counts()
            fig.add_trace(
                go.Pie(labels=customer_segments.index, values=customer_segments.values,
                      name="Customer Types"),
                row=2, col=2
            )
            
            # 5. Category Performance
            category_performance = self.products_df.groupby('Category')['ProfitMargin'].mean()
            fig.add_trace(
                go.Bar(x=category_performance.index, y=category_performance.values,
                      name='Profit Margin', marker_color='#F18F01'),
                row=3, col=1
            )
            
            # 6. Price Analysis
            fig.add_trace(
                go.Scatter(x=self.products_df['UnitPrice'], y=self.products_df['ProfitMargin'],
                          mode='markers', name='Price vs Margin',
                          marker=dict(color='#C73E1D', size=8)),
                row=3, col=2
            )
            
            # Update layout
            fig.update_layout(
                title_text="Interactive Business Analytics Dashboard",
                showlegend=False,
                height=1200,
                font=dict(size=12)
            )
            
            # Save interactive dashboard
            pyo.plot(fig, filename=os.path.join(self.output_dir, 'interactive_dashboard.html'), 
                    auto_open=False)
            
            logging.info("Interactive dashboard created successfully")
            
        except Exception as e:
            logging.error(f"Error creating interactive dashboard: {e}")
    
    def create_advanced_charts(self):
        """Create advanced analytical charts"""
        try:
            logging.info("Creating advanced charts")
            
            # 1. Heatmap - Sales by Region and Month
            self._create_sales_heatmap()
            
            # 2. Funnel Chart - Sales Pipeline
            self._create_sales_funnel()
            
            # 3. Radar Chart - Performance Metrics
            self._create_performance_radar()
            
            # 4. Bubble Chart - Customer Analysis
            self._create_customer_bubble_chart()
            
            # 5. Waterfall Chart - Revenue Breakdown
            self._create_revenue_waterfall()
            
            logging.info("Advanced charts completed")
            
        except Exception as e:
            logging.error(f"Error creating advanced charts: {e}")
    
    def _create_sales_heatmap(self):
        """Create sales heatmap by region and month"""
        try:
            # Create pivot table
            sales_pivot = self.sales_df.pivot_table(
                values='TotalAmount', 
                index='Region', 
                columns='Month', 
                aggfunc='sum',
                fill_value=0
            )
            
            plt.figure(figsize=(12, 6))
            sns.heatmap(sales_pivot, annot=True, fmt='.0f', cmap='YlOrRd', 
                       cbar_kws={'label': 'Revenue ($)'})
            plt.title('Sales Heatmap - Revenue by Region and Month')
            plt.xlabel('Month')
            plt.ylabel('Region')
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'sales_heatmap.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating sales heatmap: {e}")
    
    def _create_sales_funnel(self):
        """Create sales funnel chart"""
        try:
            # Calculate funnel stages
            funnel_data = {
                'Stage': ['Leads', 'Qualified', 'Proposal', 'Negotiation', 'Closed Won'],
                'Count': [1000, 750, 500, 350, 250],
                'Conversion': [100, 75, 50, 35, 25]
            }
            
            fig, ax = plt.subplots(figsize=(10, 8))
            
            # Create funnel
            for i, (stage, count) in enumerate(zip(funnel_data['Stage'], funnel_data['Count'])):
                width = count
                left = (1000 - width) / 2
                ax.barh(i, width, left=left, height=0.8, 
                       color=plt.cm.viridis(i/len(funnel_data['Stage'])))
                ax.text(500, i, f'{stage}\n{count} ({funnel_data["Conversion"][i]}%)', 
                       ha='center', va='center', fontweight='bold')
            
            ax.set_xlim(0, 1000)
            ax.set_ylim(-0.5, len(funnel_data['Stage']) - 0.5)
            ax.set_xlabel('Number of Opportunities')
            ax.set_title('Sales Funnel Analysis')
            ax.set_yticks([])
            ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'sales_funnel.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating sales funnel: {e}")
    
    def _create_performance_radar(self):
        """Create performance radar chart"""
        try:
            # Calculate performance metrics
            metrics = {
                'Revenue Growth': 85,
                'Customer Satisfaction': 92,
                'Market Share': 78,
                'Profit Margin': 88,
                'Operational Efficiency': 82,
                'Innovation Index': 75
            }
            
            # Convert to arrays for plotting
            categories = list(metrics.keys())
            values = list(metrics.values())
            
            # Create radar chart
            fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
            
            # Number of variables
            N = len(categories)
            
            # Compute angle for each axis
            angles = [n / float(N) * 2 * np.pi for n in range(N)]
            angles += angles[:1]
            
            # Add the first point to close the circle
            values += values[:1]
            
            # Plot
            ax.plot(angles, values, 'o-', linewidth=2, color=self.colors['primary'])
            ax.fill(angles, values, alpha=0.25, color=self.colors['primary'])
            
            # Add labels
            ax.set_xticks(angles[:-1])
            ax.set_xticklabels(categories)
            ax.set_ylim(0, 100)
            ax.set_title('Business Performance Radar Chart', size=16, fontweight='bold', pad=20)
            
            # Add grid
            ax.grid(True)
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'performance_radar.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating performance radar: {e}")
    
    def _create_customer_bubble_chart(self):
        """Create customer bubble chart"""
        try:
            # Calculate customer metrics
            customer_metrics = self.sales_df.groupby('CustomerID').agg({
                'TotalAmount': 'sum',
                'OrderID': 'count',
                'OrderDate': lambda x: (x.max() - x.min()).days
            }).reset_index()
            
            customer_metrics.columns = ['CustomerID', 'LifetimeValue', 'OrderCount', 'CustomerSpan']
            
            plt.figure(figsize=(12, 8))
            scatter = plt.scatter(customer_metrics['OrderCount'], customer_metrics['LifetimeValue'],
                                s=customer_metrics['CustomerSpan']*2, alpha=0.6,
                                c=customer_metrics['LifetimeValue'], cmap='viridis')
            
            plt.xlabel('Number of Orders')
            plt.ylabel('Lifetime Value ($)')
            plt.title('Customer Analysis Bubble Chart\n(Bubble size = Customer span in days)')
            plt.colorbar(scatter, label='Lifetime Value ($)')
            plt.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'customer_bubble_chart.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating customer bubble chart: {e}")
    
    def _create_revenue_waterfall(self):
        """Create revenue waterfall chart"""
        try:
            # Calculate revenue components
            revenue_data = {
                'Starting Revenue': 100000,
                'New Sales': 45000,
                'Returns': -5000,
                'Discounts': -8000,
                'Adjustments': -2000,
                'Final Revenue': 130000
            }
            
            categories = list(revenue_data.keys())
            values = list(revenue_data.values())
            
            # Create waterfall chart
            fig, ax = plt.subplots(figsize=(12, 6))
            
            # Calculate cumulative values
            cumulative = np.zeros(len(values))
            cumulative[0] = values[0]
            
            for i in range(1, len(values)):
                cumulative[i] = cumulative[i-1] + values[i]
            
            # Plot bars
            for i, (cat, val, cum) in enumerate(zip(categories, values, cumulative)):
                if val >= 0:
                    ax.bar(i, val, bottom=cum-val, color='green', alpha=0.7)
                else:
                    ax.bar(i, val, bottom=cum, color='red', alpha=0.7)
                
                # Add value labels
                ax.text(i, cum + (val/2), f'{val:,.0f}', ha='center', va='center', fontweight='bold')
            
            ax.set_xticks(range(len(categories)))
            ax.set_xticklabels(categories, rotation=45, ha='right')
            ax.set_ylabel('Revenue ($)')
            ax.set_title('Revenue Waterfall Chart')
            ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'revenue_waterfall.png'), 
                       dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating revenue waterfall: {e}")
    
    def generate_visualization_report(self):
        """Generate visualization summary report"""
        try:
            report = {
                'generation_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'visualizations_created': [
                    'executive_dashboard.png',
                    'sales_dashboard.png',
                    'customer_dashboard.png',
                    'product_dashboard.png',
                    'interactive_dashboard.html',
                    'sales_heatmap.png',
                    'sales_funnel.png',
                    'performance_radar.png',
                    'customer_bubble_chart.png',
                    'revenue_waterfall.png'
                ],
                'output_directory': self.output_dir,
                'data_summary': {
                    'sales_records': len(self.sales_df),
                    'customers': len(self.customers_df),
                    'products': len(self.products_df)
                }
            }
            
            # Save report
            import json
            report_path = os.path.join(self.output_dir, 'visualization_report.json')
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            logging.info("Visualization report generated")
            return report
            
        except Exception as e:
            logging.error(f"Error generating visualization report: {e}")
            return None

def main():
    """Main execution function"""
    print("Starting advanced visualization generation...")
    
    # Initialize visualizer
    visualizer = BusinessVisualizer()
    
    # Load data
    if not visualizer.load_data():
        print("Failed to load data. Exiting...")
        return
    
    # Create visualizations
    visualizer.create_dashboard_visualizations()
    visualizer.create_advanced_charts()
    
    # Generate report
    report = visualizer.generate_visualization_report()
    
    print("Visualization generation completed successfully!")
    print(f"All visualizations saved to: {visualizer.output_dir}")

if __name__ == "__main__":
    main()

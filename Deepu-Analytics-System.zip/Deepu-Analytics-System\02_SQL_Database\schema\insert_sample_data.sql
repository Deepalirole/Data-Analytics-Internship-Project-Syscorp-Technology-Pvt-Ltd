-- Sample Data Insertion Script
-- Populates the database with realistic business data

-- Insert Regions
INSERT INTO regions (region_id, region_name, country) VALUES
(1, 'North', 'USA'),
(2, 'South', 'USA'),
(3, 'East', 'USA'),
(4, 'West', 'USA');

-- Insert Sales Representatives
INSERT INTO sales_reps (rep_id, rep_name, email, phone, hire_date, region_id, base_salary, commission_rate) VALUES
(1, 'John Smith', 'john.smith@company.com', '555-0101', '2023-01-15', 1, 60000.00, 0.0500),
(2, 'Jane Doe', 'jane.doe@company.com', '555-0102', '2023-02-20', 2, 55000.00, 0.0450),
(3, 'Bob Johnson', 'bob.johnson@company.com', '555-0103', '2023-03-10', 3, 58000.00, 0.0475),
(4, 'Alice Brown', 'alice.brown@company.com', '555-0104', '2023-04-05', 1, 62000.00, 0.0525),
(5, 'Charlie Wilson', 'charlie.wilson@company.com', '555-0105', '2023-05-12', 3, 59000.00, 0.0480),
(6, 'David Lee', 'david.lee@company.com', '555-0106', '2023-06-18', 4, 57000.00, 0.0460),
(7, 'Eve Davis', 'eve.davis@company.com', '555-0107', '2023-07-22', 2, 61000.00, 0.0510),
(8, 'Frank Miller', 'frank.miller@company.com', '555-0108', '2023-08-30', 4, 63000.00, 0.0530);

-- Insert Categories
INSERT INTO categories (category_id, category_name, description) VALUES
(1, 'Electronics', 'Electronic devices and accessories'),
(2, 'Furniture', 'Office and home furniture items');

-- Insert Customers
INSERT INTO customers (customer_id, company_name, contact_name, email, phone, address, city, state, zip_code, country, join_date, customer_type, credit_limit) VALUES
('CUST001', 'Tech Solutions Inc', 'John Smith', 'john.smith@techsolutions.com', '555-0101', '123 Tech Street', 'Seattle', 'WA', '98101', 'USA', '2023-01-15', 'Enterprise', 50000.00),
('CUST002', 'Global Enterprises', 'Jane Doe', 'jane.doe@global.com', '555-0102', '456 Business Ave', 'Dallas', 'TX', '75201', 'USA', '2023-02-20', 'Enterprise', 75000.00),
('CUST003', 'Startup Innovations', 'Bob Johnson', 'bob.j@startup.io', '555-0103', '789 Innovation Way', 'Boston', 'MA', '02101', 'USA', '2023-03-10', 'SME', 25000.00),
('CUST004', 'Creative Agency', 'Alice Brown', 'alice@creative.agency', '555-0104', '321 Design Blvd', 'Los Angeles', 'CA', '90001', 'USA', '2023-04-05', 'SME', 30000.00),
('CUST005', 'Consulting Partners', 'Charlie Wilson', 'charlie@consulting.com', '555-0105', '654 Strategy Lane', 'Chicago', 'IL', '60601', 'USA', '2023-05-12', 'Enterprise', 60000.00),
('CUST006', 'Retail Store Co', 'David Lee', 'david.lee@retail.com', '555-0106', '987 Market St', 'Phoenix', 'AZ', '85001', 'USA', '2023-06-18', 'SME', 20000.00),
('CUST007', 'Manufacturing Pro', 'Eve Davis', 'eve@manufacturing.com', '555-0107', '147 Factory Dr', 'Detroit', 'MI', '48201', 'USA', '2023-07-22', 'Enterprise', 80000.00),
('CUST008', 'Service Experts', 'Frank Miller', 'frank@service.com', '555-0108', '258 Service Rd', 'Miami', 'FL', '33101', 'USA', '2023-08-30', 'SME', 15000.00),
('CUST009', 'Digital Solutions', 'Grace Taylor', 'grace@digital.com', '555-0109', '369 Digital Ave', 'Denver', 'CO', '80201', 'USA', '2023-09-14', 'SME', 35000.00),
('CUST010', 'Software Company', 'Henry Clark', 'henry@software.com', '555-0110', '741 Code Ln', 'Portland', 'OR', '97201', 'USA', '2023-10-08', 'Enterprise', 100000.00),
('CUST011', 'Marketing Agency', 'Ivy Martinez', 'ivy@marketing.com', '555-0111', '852 Ad Street', 'Atlanta', 'GA', '30301', 'USA', '2023-11-11', 'SME', 28000.00),
('CUST012', 'Technology Group', 'Jack Anderson', 'jack@techgroup.com', '555-0112', '963 Innovation Dr', 'Minneapolis', 'MN', '55401', 'USA', '2023-12-20', 'Enterprise', 90000.00);

-- Insert Products
INSERT INTO products (product_id, product_name, category_id, supplier, unit_cost, unit_price, reorder_level, discontinued, launch_date, weight) VALUES
('PROD001', 'Laptop Pro', 1, 'TechCorp', 800.00, 1200.00, 20, FALSE, '2023-01-01', 2.5),
('PROD002', 'Office Chair', 2, 'FurniMax', 150.00, 250.00, 30, FALSE, '2023-02-15', 15.0),
('PROD003', 'Wireless Mouse', 1, 'TechCorp', 25.00, 45.00, 50, FALSE, '2023-03-01', 0.2),
('PROD004', 'Standing Desk', 2, 'FurniMax', 500.00, 800.00, 15, FALSE, '2023-04-10', 35.0),
('PROD005', 'Monitor 27"', 1, 'TechCorp', 220.00, 350.00, 25, FALSE, '2023-05-20', 5.5),
('PROD006', 'Keyboard Mechanical', 1, 'TechCorp', 70.00, 120.00, 40, FALSE, '2023-06-01', 1.2),
('PROD007', 'Bookshelf', 2, 'FurniMax', 180.00, 300.00, 20, FALSE, '2023-07-15', 25.0),
('PROD008', 'Tablet Pro', 1, 'TechCorp', 380.00, 600.00, 30, FALSE, '2023-08-10', 0.8),
('PROD009', 'Desk Lamp', 2, 'FurniMax', 45.00, 80.00, 60, FALSE, '2023-09-05', 2.0),
('PROD010', 'Smartphone Pro', 1, 'TechCorp', 600.00, 900.00, 35, FALSE, '2023-10-01', 0.3),
('PROD011', 'Filing Cabinet', 2, 'FurniMax', 90.00, 150.00, 25, FALSE, '2023-11-12', 20.0),
('PROD012', 'Laptop Stand', 1, 'TechCorp', 35.00, 60.00, 45, FALSE, '2023-12-01', 1.5),
('PROD013', 'Executive Chair', 2, 'FurniMax', 300.00, 450.00, 18, FALSE, '2024-01-15', 18.0),
('PROD014', 'Webcam HD', 1, 'TechCorp', 45.00, 75.00, 55, FALSE, '2024-02-01', 0.4),
('PROD015', 'Conference Table', 2, 'FurniMax', 800.00, 1200.00, 10, FALSE, '2024-03-01', 45.0),
('PROD016', 'USB Hub', 1, 'TechCorp', 20.00, 35.00, 70, FALSE, '2024-04-01', 0.3),
('PROD017', 'Whiteboard', 2, 'FurniMax', 120.00, 200.00, 22, FALSE, '2024-05-01', 8.0),
('PROD018', 'Headphones Pro', 1, 'TechCorp', 110.00, 180.00, 38, FALSE, '2024-06-01', 0.5),
('PROD019', 'Storage Cabinet', 2, 'FurniMax', 210.00, 350.00, 16, FALSE, '2024-07-01', 30.0),
('PROD020', 'External SSD', 1, 'TechCorp', 75.00, 120.00, 48, FALSE, '2024-08-01', 0.1);

-- Insert Orders
INSERT INTO orders (order_id, customer_id, order_date, required_date, shipped_date, ship_via, freight, sales_rep_id, region_id, order_status) VALUES
(1001, 'CUST001', '2024-01-15', '2024-01-22', '2024-01-17', 1, 25.00, 1, 1, 'Delivered'),
(1002, 'CUST002', '2024-01-16', '2024-01-23', '2024-01-18', 2, 15.00, 2, 2, 'Delivered'),
(1003, 'CUST003', '2024-01-17', '2024-01-24', '2024-01-19', 1, 10.00, 3, 3, 'Delivered'),
(1004, 'CUST001', '2024-01-18', '2024-01-25', '2024-01-20', 3, 35.00, 1, 4, 'Delivered'),
(1005, 'CUST004', '2024-01-19', '2024-01-26', '2024-01-21', 1, 20.00, 4, 1, 'Delivered'),
(1006, 'CUST005', '2024-01-20', '2024-01-27', '2024-01-22', 2, 18.00, 5, 2, 'Delivered'),
(1007, 'CUST002', '2024-01-21', '2024-01-28', '2024-01-23', 1, 22.00, 2, 3, 'Delivered'),
(1008, 'CUST006', '2024-01-22', '2024-01-29', '2024-01-24', 3, 30.00, 6, 4, 'Delivered'),
(1009, 'CUST003', '2024-01-23', '2024-01-30', '2024-01-25', 1, 12.00, 3, 1, 'Delivered'),
(1010, 'CUST007', '2024-01-24', '2024-01-31', '2024-01-26', 2, 28.00, 7, 2, 'Delivered'),
(1011, 'CUST001', '2024-01-25', '2024-02-01', '2024-01-27', 1, 15.00, 1, 3, 'Delivered'),
(1012, 'CUST008', '2024-01-26', '2024-02-02', '2024-01-28', 3, 8.00, 8, 4, 'Delivered'),
(1013, 'CUST004', '2024-01-27', '2024-02-03', '2024-01-29', 1, 25.00, 4, 1, 'Delivered'),
(1014, 'CUST009', '2024-01-28', '2024-02-04', '2024-01-30', 2, 14.00, 1, 2, 'Delivered'),
(1015, 'CUST005', '2024-01-29', '2024-02-05', '2024-01-31', 3, 40.00, 5, 3, 'Delivered'),
(1016, 'CUST010', '2024-01-30', '2024-02-06', '2024-02-01', 1, 6.00, 4, 4, 'Delivered'),
(1017, 'CUST002', '2024-01-31', '2024-02-07', '2024-02-02', 2, 18.00, 2, 1, 'Delivered'),
(1018, 'CUST011', '2024-02-01', '2024-02-08', '2024-02-03', 1, 20.00, 3, 2, 'Delivered'),
(1019, 'CUST003', '2024-02-02', '2024-02-09', '2024-02-04', 3, 22.00, 3, 3, 'Delivered'),
(1020, 'CUST012', '2024-02-03', '2024-02-10', '2024-02-05', 1, 10.00, 6, 4, 'Delivered');

-- Insert Order Details
INSERT INTO order_details (order_id, product_id, quantity, unit_price, discount) VALUES
(1001, 'PROD001', 2, 1200.00, 0.10),
(1002, 'PROD002', 5, 250.00, 0.05),
(1003, 'PROD003', 10, 45.00, 0.00),
(1004, 'PROD004', 1, 800.00, 0.15),
(1005, 'PROD005', 3, 350.00, 0.08),
(1006, 'PROD006', 8, 120.00, 0.00),
(1007, 'PROD007', 2, 300.00, 0.10),
(1008, 'PROD008', 4, 600.00, 0.12),
(1009, 'PROD009', 6, 80.00, 0.05),
(1010, 'PROD010', 5, 900.00, 0.15),
(1011, 'PROD011', 3, 150.00, 0.00),
(1012, 'PROD012', 7, 60.00, 0.08),
(1013, 'PROD013', 1, 450.00, 0.10),
(1014, 'PROD014', 9, 75.00, 0.00),
(1015, 'PROD015', 2, 1200.00, 0.12),
(1016, 'PROD016', 12, 35.00, 0.05),
(1017, 'PROD017', 4, 200.00, 0.08),
(1018, 'PROD018', 6, 180.00, 0.10),
(1019, 'PROD019', 3, 350.00, 0.05),
(1020, 'PROD020', 8, 120.00, 0.00);

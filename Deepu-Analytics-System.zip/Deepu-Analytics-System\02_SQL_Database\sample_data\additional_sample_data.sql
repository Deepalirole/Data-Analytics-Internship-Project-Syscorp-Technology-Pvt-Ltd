-- Additional Sample Data for Extended Analysis
-- More comprehensive dataset for better analytics testing

-- Insert more orders for better trend analysis
INSERT INTO orders (order_id, customer_id, order_date, required_date, shipped_date, ship_via, freight, sales_rep_id, region_id, order_status) VALUES
(1021, 'CUST001', '2024-02-04', '2024-02-11', '2024-02-06', 1, 18.00, 1, 1, 'Delivered'),
(1022, 'CUST002', '2024-02-05', '2024-02-12', '2024-02-07', 2, 22.00, 2, 2, 'Delivered'),
(1023, 'CUST003', '2024-02-06', '2024-02-13', '2024-02-08', 1, 15.00, 3, 3, 'Delivered'),
(1024, 'CUST004', '2024-02-07', '2024-02-14', '2024-02-09', 3, 28.00, 4, 1, 'Delivered'),
(1025, 'CUST005', '2024-02-08', '2024-02-15', '2024-02-10', 1, 20.00, 5, 2, 'Delivered'),
(1026, 'CUST006', '2024-02-09', '2024-02-16', '2024-02-11', 2, 12.00, 6, 4, 'Delivered'),
(1027, 'CUST007', '2024-02-10', '2024-02-17', '2024-02-12', 1, 25.00, 7, 2, 'Delivered'),
(1028, 'CUST008', '2024-02-11', '2024-02-18', '2024-02-13', 3, 30.00, 8, 4, 'Delivered'),
(1029, 'CUST009', '2024-02-12', '2024-02-19', '2024-02-14', 1, 16.00, 1, 1, 'Delivered'),
(1030, 'CUST010', '2024-02-13', '2024-02-20', '2024-02-15', 2, 35.00, 4, 4, 'Delivered'),
(1031, 'CUST011', '2024-02-14', '2024-02-21', '2024-02-16', 1, 18.00, 3, 2, 'Delivered'),
(1032, 'CUST012', '2024-02-15', '2024-02-22', '2024-02-17', 3, 22.00, 6, 4, 'Delivered'),
(1033, 'CUST001', '2024-02-16', '2024-02-23', '2024-02-18', 1, 14.00, 1, 1, 'Delivered'),
(1034, 'CUST002', '2024-02-17', '2024-02-24', '2024-02-19', 2, 26.00, 2, 2, 'Delivered'),
(1035, 'CUST003', '2024-02-18', '2024-02-25', '2024-02-20', 1, 20.00, 3, 3, 'Delivered'),
(1036, 'CUST004', '2024-02-19', '2024-02-26', '2024-02-21', 3, 32.00, 4, 1, 'Delivered'),
(1037, 'CUST005', '2024-02-20', '2024-02-27', '2024-02-22', 1, 24.00, 5, 2, 'Delivered'),
(1038, 'CUST006', '2024-02-21', '2024-02-28', '2024-02-23', 2, 10.00, 6, 4, 'Delivered'),
(1039, 'CUST007', '2024-02-22', '2024-03-01', '2024-02-24', 1, 28.00, 7, 2, 'Delivered'),
(1040, 'CUST008', '2024-02-23', '2024-03-02', '2024-02-25', 3, 34.00, 8, 4, 'Delivered');

-- Insert corresponding order details
INSERT INTO order_details (order_id, product_id, quantity, unit_price, discount) VALUES
(1021, 'PROD001', 1, 1200.00, 0.05),
(1022, 'PROD002', 3, 250.00, 0.10),
(1023, 'PROD003', 8, 45.00, 0.00),
(1024, 'PROD004', 2, 800.00, 0.08),
(1025, 'PROD005', 4, 350.00, 0.12),
(1026, 'PROD006', 6, 120.00, 0.00),
(1027, 'PROD007', 3, 300.00, 0.05),
(1028, 'PROD008', 2, 600.00, 0.15),
(1029, 'PROD009', 7, 80.00, 0.00),
(1030, 'PROD010', 3, 900.00, 0.10),
(1031, 'PROD011', 4, 150.00, 0.00),
(1032, 'PROD012', 9, 60.00, 0.08),
(1033, 'PROD013', 2, 450.00, 0.12),
(1034, 'PROD014', 5, 75.00, 0.00),
(1035, 'PROD015', 1, 1200.00, 0.15),
(1036, 'PROD016', 10, 35.00, 0.05),
(1037, 'PROD017', 3, 200.00, 0.08),
(1038, 'PROD018', 8, 180.00, 0.10),
(1039, 'PROD019', 2, 350.00, 0.05),
(1040, 'PROD020', 11, 120.00, 0.00);

-- Add some pending orders for pipeline analysis
INSERT INTO orders (order_id, customer_id, order_date, required_date, shipped_date, ship_via, freight, sales_rep_id, region_id, order_status) VALUES
(1041, 'CUST009', '2024-02-24', '2024-03-03', NULL, 1, 18.00, 1, 1, 'Pending'),
(1042, 'CUST010', '2024-02-25', '2024-03-04', NULL, 2, 25.00, 4, 4, 'Processing'),
(1043, 'CUST011', '2024-02-26', '2024-03-05', NULL, 1, 20.00, 3, 2, 'Pending'),
(1044, 'CUST012', '2024-02-27', '2024-03-06', NULL, 3, 30.00, 6, 4, 'Processing');

-- Insert order details for pending orders
INSERT INTO order_details (order_id, product_id, quantity, unit_price, discount) VALUES
(1041, 'PROD001', 2, 1200.00, 0.00),
(1041, 'PROD005', 1, 350.00, 0.00),
(1042, 'PROD010', 1, 900.00, 0.05),
(1042, 'PROD015', 1, 1200.00, 0.10),
(1043, 'PROD002', 4, 250.00, 0.00),
(1043, 'PROD007', 2, 300.00, 0.00),
(1044, 'PROD008', 3, 600.00, 0.08),
(1044, 'PROD018', 4, 180.00, 0.05);

-- Insert more customers for diversity
INSERT INTO customers (customer_id, company_name, contact_name, email, phone, address, city, state, zip_code, country, join_date, customer_type, credit_limit) VALUES
('CUST013', 'Innovation Labs', 'Kevin Chen', 'kevin@innovationlabs.com', '555-0113', '123 Research Drive', 'San Francisco', 'CA', '94105', 'USA', '2024-01-05', 'SME', 40000.00),
('CUST014', 'Data Systems Co', 'Lisa Wang', 'lisa@datasystems.com', '555-0114', '456 Analytics Blvd', 'Austin', 'TX', '78701', 'USA', '2024-01-10', 'Enterprise', 120000.00),
('CUST015', 'Cloud Services Inc', 'Mike Johnson', 'mike@cloudservices.com', '555-0115', '789 Cloud Street', 'Seattle', 'WA', '98109', 'USA', '2024-01-15', 'Enterprise', 95000.00),
('CUST016', 'Startup Hub', 'Sarah Davis', 'sarah@startup.hub', '555-0116', '321 Innovation Ave', 'Portland', 'OR', '97204', 'USA', '2024-01-20', 'SME', 30000.00),
('CUST017', 'Tech Consulting', 'Tom Wilson', 'tom@techconsulting.com', '555-0117', '654 Consulting Way', 'Denver', 'CO', '80202', 'USA', '2024-01-25', 'SME', 35000.00);

-- Add more products for variety
INSERT INTO products (product_id, product_name, category_id, supplier, unit_cost, unit_price, reorder_level, discontinued, launch_date, weight) VALUES
('PROD021', 'Gaming Laptop', 1, 'TechCorp', 1200.00, 1800.00, 15, FALSE, '2024-01-01', 3.2),
('PROD022', 'Ergonomic Mouse', 1, 'TechCorp', 35.00, 65.00, 40, FALSE, '2024-01-15', 0.3),
('PROD023', 'Standing Desk Pro', 2, 'FurniMax', 600.00, 950.00, 12, FALSE, '2024-02-01', 40.0),
('PROD024', 'Wireless Keyboard', 1, 'TechCorp', 55.00, 95.00, 35, FALSE, '2024-02-15', 0.8),
('PROD025', 'Office Cabinet', 2, 'FurniMax', 250.00, 400.00, 18, FALSE, '2024-03-01', 28.0),
('PROD026', '4K Monitor', 1, 'TechCorp', 350.00, 550.00, 20, FALSE, '2024-03-15', 6.5),
('PROD027', 'Conference Phone', 1, 'TechCorp', 180.00, 280.00, 25, FALSE, '2024-04-01', 1.2),
('PROD028', 'Storage Unit', 2, 'FurniMax', 150.00, 280.00, 22, FALSE, '2024-04-15', 22.0),
('PROD029', 'Docking Station', 1, 'TechCorp', 120.00, 200.00, 30, FALSE, '2024-05-01', 0.9),
('PROD030', 'Reception Desk', 2, 'FurniMax', 450.00, 750.00, 8, FALSE, '2024-05-15', 55.0);

-- Insert some orders with new products
INSERT INTO orders (order_id, customer_id, order_date, required_date, shipped_date, ship_via, freight, sales_rep_id, region_id, order_status) VALUES
(1045, 'CUST013', '2024-02-28', '2024-03-07', '2024-03-01', 1, 22.00, 4, 1, 'Delivered'),
(1046, 'CUST014', '2024-03-01', '2024-03-08', '2024-03-02', 2, 35.00, 2, 2, 'Delivered'),
(1047, 'CUST015', '2024-03-02', '2024-03-09', '2024-03-03', 1, 18.00, 1, 1, 'Delivered'),
(1048, 'CUST016', '2024-03-03', '2024-03-10', '2024-03-04', 3, 28.00, 4, 4, 'Delivered'),
(1049, 'CUST017', '2024-03-04', '2024-03-11', '2024-03-05', 1, 15.00, 3, 3, 'Delivered');

INSERT INTO order_details (order_id, product_id, quantity, unit_price, discount) VALUES
(1045, 'PROD021', 1, 1800.00, 0.10),
(1045, 'PROD022', 3, 65.00, 0.00),
(1046, 'PROD023', 2, 950.00, 0.08),
(1046, 'PROD024', 4, 95.00, 0.00),
(1047, 'PROD025', 1, 400.00, 0.05),
(1047, 'PROD026', 2, 550.00, 0.12),
(1048, 'PROD027', 3, 280.00, 0.00),
(1048, 'PROD028', 2, 280.00, 0.08),
(1049, 'PROD029', 5, 200.00, 0.00),
(1049, 'PROD030', 1, 750.00, 0.10);

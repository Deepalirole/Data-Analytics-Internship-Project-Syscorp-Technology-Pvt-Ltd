-- Business Analytics Queries
-- Comprehensive SQL queries for business intelligence and decision support

-- 1. Total Revenue Analysis
SELECT 
    SUM(line_total) AS total_revenue,
    COUNT(DISTINCT o.order_id) AS total_orders,
    AVG(line_total) AS avg_order_value,
    SUM(od.quantity) AS total_units_sold
FROM orders o
JOIN order_details od ON o.order_id = od.order_id
WHERE o.order_status = 'Delivered';

-- 2. Monthly Revenue Trend
SELECT 
    DATE_FORMAT(o.order_date, '%Y-%m') AS month,
    SUM(line_total) AS monthly_revenue,
    COUNT(DISTINCT o.order_id) AS monthly_orders,
    AVG(line_total) AS avg_order_size,
    SUM(line_total) - LAG(SUM(line_total), 1) OVER (ORDER BY DATE_FORMAT(o.order_date, '%Y-%m')) AS revenue_change
FROM orders o
JOIN order_details od ON o.order_id = od.order_id
WHERE o.order_status = 'Delivered'
GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
ORDER BY month;

-- 3. Regional Performance Analysis
SELECT 
    r.region_name,
    SUM(line_total) AS total_revenue,
    COUNT(DISTINCT o.order_id) AS order_count,
    AVG(line_total) AS avg_order_value,
    SUM(od.quantity) AS total_quantity,
    (SUM(line_total) / (SELECT SUM(line_total) FROM orders o2 JOIN order_details od2 ON o2.order_id = od2.order_id WHERE o2.order_status = 'Delivered') * 100) AS revenue_percentage
FROM regions r
LEFT JOIN orders o ON r.region_id = o.region_id
LEFT JOIN order_details od ON o.order_id = od.order_id
WHERE o.order_status = 'Delivered'
GROUP BY r.region_id, r.region_name
ORDER BY total_revenue DESC;

-- 4. Top 10 Products by Revenue
SELECT 
    p.product_name,
    cat.category_name,
    SUM(od.quantity) AS total_quantity,
    SUM(line_total) AS total_revenue,
    AVG(od.unit_price) AS avg_selling_price,
    SUM(line_total) - (SUM(od.quantity) * p.unit_cost) AS total_profit,
    (SUM(line_total) - (SUM(od.quantity) * p.unit_cost)) / SUM(line_total) * 100 AS profit_margin
FROM products p
JOIN order_details od ON p.product_id = od.product_id
JOIN categories cat ON p.category_id = cat.category_id
JOIN orders o ON od.order_id = o.order_id
WHERE o.order_status = 'Delivered'
GROUP BY p.product_id, p.product_name, cat.category_name, p.unit_cost
ORDER BY total_revenue DESC
LIMIT 10;

-- 5. Customer Segmentation Analysis
SELECT 
    c.customer_type,
    COUNT(DISTINCT c.customer_id) AS customer_count,
    COUNT(DISTINCT o.order_id) AS total_orders,
    SUM(line_total) AS total_revenue,
    AVG(line_total) AS avg_order_value,
    SUM(line_total) / COUNT(DISTINCT c.customer_id) AS revenue_per_customer
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
LEFT JOIN order_details od ON o.order_id = od.order_id
WHERE o.order_status = 'Delivered'
GROUP BY c.customer_type
ORDER BY total_revenue DESC;

-- 6. Sales Representative Performance
SELECT 
    sr.rep_name,
    r.region_name,
    COUNT(DISTINCT o.order_id) AS orders_handled,
    SUM(line_total) AS total_sales,
    AVG(line_total) AS avg_order_value,
    SUM(od.discount * od.quantity * od.unit_price) AS total_discount_given,
    sr.base_salary,
    sr.commission_rate,
    sr.base_salary + (SUM(line_total) * sr.commission_rate) AS total_compensation
FROM sales_reps sr
LEFT JOIN orders o ON sr.rep_id = o.sales_rep_id
LEFT JOIN order_details od ON o.order_id = od.order_id
LEFT JOIN regions r ON sr.region_id = r.region_id
WHERE o.order_status = 'Delivered'
GROUP BY sr.rep_id, sr.rep_name, r.region_name, sr.base_salary, sr.commission_rate
ORDER BY total_sales DESC;

-- 7. Category Performance Analysis
SELECT 
    cat.category_name,
    COUNT(DISTINCT p.product_id) AS product_count,
    SUM(od.quantity) AS total_quantity,
    SUM(line_total) AS total_revenue,
    AVG(od.unit_price) AS avg_price,
    SUM(line_total) - (SUM(od.quantity) * AVG(p.unit_cost)) AS estimated_profit,
    (SUM(line_total) / (SELECT SUM(line_total) FROM orders o2 JOIN order_details od2 ON o2.order_id = od2.order_id WHERE o2.order_status = 'Delivered') * 100) AS revenue_share
FROM categories cat
LEFT JOIN products p ON cat.category_id = p.category_id
LEFT JOIN order_details od ON p.product_id = od.product_id
LEFT JOIN orders o ON od.order_id = o.order_id
WHERE o.order_status = 'Delivered'
GROUP BY cat.category_id, cat.category_name
ORDER BY total_revenue DESC;

-- 8. Customer Lifetime Value (CLV) Analysis
SELECT 
    c.customer_id,
    c.company_name,
    c.customer_type,
    COUNT(DISTINCT o.order_id) AS order_frequency,
    DATEDIFF(MAX(o.order_date), MIN(o.order_date)) AS customer_age_days,
    SUM(line_total) AS total_lifetime_value,
    AVG(line_total) AS avg_order_value,
    CASE 
        WHEN DATEDIFF(MAX(o.order_date), MIN(o.order_date)) > 0 
        THEN SUM(line_total) / (DATEDIFF(MAX(o.order_date), MIN(o.order_date)) / 30)
        ELSE 0 
    END AS monthly_value
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
LEFT JOIN order_details od ON o.order_id = od.order_id
WHERE o.order_status = 'Delivered'
GROUP BY c.customer_id, c.company_name, c.customer_type
ORDER BY total_lifetime_value DESC;

-- 9. Product Profitability Analysis
SELECT 
    p.product_name,
    p.unit_cost,
    p.unit_price,
    SUM(od.quantity) AS units_sold,
    SUM(line_total) AS total_revenue,
    SUM(od.quantity * p.unit_cost) AS total_cost,
    SUM(line_total) - SUM(od.quantity * p.unit_cost) AS total_profit,
    (SUM(line_total) - SUM(od.quantity * p.unit_cost)) / SUM(line_total) * 100 AS profit_margin,
    CASE 
        WHEN SUM(line_total) - SUM(od.quantity * p.unit_cost) > 0 THEN 'Profitable'
        ELSE 'Not Profitable'
    END AS profitability_status
FROM products p
JOIN order_details od ON p.product_id = od.product_id
JOIN orders o ON od.order_id = o.order_id
WHERE o.order_status = 'Delivered'
GROUP BY p.product_id, p.product_name, p.unit_cost, p.unit_price
ORDER BY total_profit DESC;

-- 10. Discount Impact Analysis
SELECT 
    CASE 
        WHEN od.discount = 0 THEN 'No Discount'
        WHEN od.discount <= 0.05 THEN 'Low Discount (1-5%)'
        WHEN od.discount <= 0.10 THEN 'Medium Discount (6-10%)'
        ELSE 'High Discount (>10%)'
    END AS discount_category,
    COUNT(DISTINCT od.order_detail_id) AS transaction_count,
    SUM(od.quantity) AS total_quantity,
    SUM(line_total) AS total_revenue,
    AVG(od.discount) * 100 AS avg_discount_percentage,
    AVG(od.unit_price) AS avg_unit_price
FROM order_details od
JOIN orders o ON od.order_id = o.order_id
WHERE o.order_status = 'Delivered'
GROUP BY discount_category
ORDER BY total_revenue DESC;

-- 11. Order Status Analysis
SELECT 
    o.order_status,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(line_total) AS potential_revenue,
    AVG(DATEDIFF(COALESCE(o.shipped_date, CURRENT_DATE), o.order_date)) AS avg_processing_days
FROM orders o
LEFT JOIN order_details od ON o.order_id = od.order_id
GROUP BY o.order_status
ORDER BY order_count DESC;

-- 12. Seasonal Sales Analysis
SELECT 
    CASE 
        WHEN MONTH(o.order_date) IN (12, 1, 2) THEN 'Winter'
        WHEN MONTH(o.order_date) IN (3, 4, 5) THEN 'Spring'
        WHEN MONTH(o.order_date) IN (6, 7, 8) THEN 'Summer'
        ELSE 'Fall'
    END AS season,
    YEAR(o.order_date) AS year,
    SUM(line_total) AS seasonal_revenue,
    COUNT(DISTINCT o.order_id) AS seasonal_orders,
    AVG(line_total) AS avg_order_value
FROM orders o
JOIN order_details od ON o.order_id = od.order_id
WHERE o.order_status = 'Delivered'
GROUP BY season, YEAR(o.order_date)
ORDER BY year, season;

-- 13. Customer Retention Analysis
SELECT 
    c.customer_id,
    c.company_name,
    MIN(o.order_date) AS first_purchase,
    MAX(o.order_date) AS last_purchase,
    COUNT(DISTINCT o.order_id) AS total_orders,
    DATEDIFF(MAX(o.order_date), MIN(o.order_date)) AS customer_lifetime_days,
    CASE 
        WHEN MAX(o.order_date) >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) THEN 'Active'
        WHEN MAX(o.order_date) >= DATE_SUB(CURRENT_DATE, INTERVAL 90 DAY) THEN 'Recent'
        ELSE 'Inactive'
    END AS customer_status
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE o.order_status = 'Delivered'
GROUP BY c.customer_id, c.company_name
ORDER BY customer_lifetime_days DESC;

-- 14. Product Affinity Analysis (Products frequently bought together)
SELECT 
    od1.product_id AS product_1,
    p1.product_name AS product_1_name,
    od2.product_id AS product_2,
    p2.product_name AS product_2_name,
    COUNT(*) AS purchase_frequency,
    COUNT(DISTINCT od1.order_id) AS unique_orders
FROM order_details od1
JOIN order_details od2 ON od1.order_id = od2.order_id AND od1.product_id < od2.product_id
JOIN products p1 ON od1.product_id = p1.product_id
JOIN products p2 ON od2.product_id = p2.product_id
JOIN orders o ON od1.order_id = o.order_id
WHERE o.order_status = 'Delivered'
GROUP BY od1.product_id, od2.product_id, p1.product_name, p2.product_name
HAVING purchase_frequency > 1
ORDER BY purchase_frequency DESC
LIMIT 10;

-- 15. Revenue Forecasting (Simple Moving Average)
WITH monthly_revenue AS (
    SELECT 
        DATE_FORMAT(order_date, '%Y-%m') AS month,
        SUM(line_total) AS revenue
    FROM orders o
    JOIN order_details od ON o.order_id = od.order_id
    WHERE o.order_status = 'Delivered'
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
)
SELECT 
    month,
    revenue,
    AVG(revenue) OVER (ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS moving_avg_3_months,
    revenue - LAG(revenue, 1) OVER (ORDER BY month) AS month_over_month_change,
    (revenue - LAG(revenue, 1) OVER (ORDER BY month)) / LAG(revenue, 1) OVER (ORDER BY month) * 100 AS growth_rate
FROM monthly_revenue
ORDER BY month;

-- 16. High-Value Customer Identification
WITH customer_metrics AS (
    SELECT 
        c.customer_id,
        c.company_name,
        c.customer_type,
        COUNT(DISTINCT o.order_id) AS order_count,
        SUM(line_total) AS total_revenue,
        AVG(line_total) AS avg_order_value,
        MAX(o.order_date) AS last_order_date
    FROM customers c
    JOIN orders o ON c.customer_id = o.customer_id
    JOIN order_details od ON o.order_id = od.order_id
    WHERE o.order_status = 'Delivered'
    GROUP BY c.customer_id, c.company_name, c.customer_type
)
SELECT 
    customer_id,
    company_name,
    customer_type,
    order_count,
    total_revenue,
    avg_order_value,
    last_order_date,
    CASE 
        WHEN total_revenue > 10000 AND order_count > 3 THEN 'Platinum'
        WHEN total_revenue > 5000 AND order_count > 2 THEN 'Gold'
        WHEN total_revenue > 2000 AND order_count > 1 THEN 'Silver'
        ELSE 'Bronze'
    END AS customer_tier
FROM customer_metrics
ORDER BY total_revenue DESC;

-- 17. Inventory Turnover Analysis
SELECT 
    p.product_id,
    p.product_name,
    p.unit_cost,
    p.reorder_level,
    COALESCE(SUM(od.quantity), 0) AS units_sold,
    p.unit_cost * COALESCE(SUM(od.quantity), 0) AS cost_of_goods_sold,
    CASE 
        WHEN p.unit_cost > 0 AND SUM(od.quantity) > 0 
        THEN (p.unit_cost * SUM(od.quantity)) / p.unit_cost
        ELSE 0 
    END AS inventory_turns,
    CASE 
        WHEN SUM(od.quantity) > 0 THEN 'Fast Moving'
        WHEN SUM(od.quantity) > 0 AND SUM(od.quantity) < 10 THEN 'Slow Moving'
        ELSE 'Not Sold'
    END AS movement_status
FROM products p
LEFT JOIN order_details od ON p.product_id = od.product_id
LEFT JOIN orders o ON od.order_id = o.order_id
WHERE o.order_status = 'Delivered' OR o.order_id IS NULL
GROUP BY p.product_id, p.product_name, p.unit_cost, p.reorder_level
ORDER BY units_sold DESC;

-- 18. Geographic Sales Distribution
SELECT 
    c.city,
    c.state,
    COUNT(DISTINCT c.customer_id) AS customer_count,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(line_total) AS total_revenue,
    AVG(line_total) AS avg_order_value
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
LEFT JOIN order_details od ON o.order_id = od.order_id
WHERE o.order_status = 'Delivered'
GROUP BY c.city, c.state
HAVING COUNT(DISTINCT o.order_id) > 0
ORDER BY total_revenue DESC;

-- 19. Sales Pipeline Analysis
SELECT 
    o.order_status,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(line_total) AS total_value,
    AVG(DATEDIFF(COALESCE(o.shipped_date, CURRENT_DATE), o.order_date)) AS avg_days_in_status,
    COUNT(DISTINCT o.customer_id) AS unique_customers
FROM orders o
LEFT JOIN order_details od ON o.order_id = od.order_id
GROUP BY o.order_status
ORDER BY total_value DESC;

-- 20. Cross-Selling Opportunity Analysis
SELECT 
    c.customer_id,
    c.company_name,
    p.category_name AS purchased_category,
    COUNT(DISTINCT od.product_id) AS products_in_category,
    cat.category_name AS unpurchased_category,
    COUNT(DISTINCT p2.product_id) AS available_products_in_category
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_details od ON o.order_id = od.order_id
JOIN products p ON od.product_id = p.product_id
JOIN categories cat ON p.category_id != cat.category_id
JOIN products p2 ON cat.category_id = p2.category_id
WHERE o.order_status = 'Delivered'
GROUP BY c.customer_id, c.company_name, p.category_name, cat.category_name
HAVING products_in_category > 0 AND available_products_in_category > 0
ORDER BY c.customer_id, available_products_in_category DESC;

#!/usr/bin/env python3
"""
Interactive Dashboard for Capstone Project
Streamlit-based interactive dashboard for business analytics
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import os

# Configure page
st.set_page_config(
    page_title="Business Analytics Dashboard",
    page_icon=":chart_with_upwards_trend:",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #2E86AB;
        text-align: center;
        margin-bottom: 2rem;
    }
    .kpi-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        margin: 0.5rem 0;
    }
    .insight-box {
        background: #f0f2f6;
        padding: 1rem;
        border-radius: 5px;
        border-left: 4px solid #2E86AB;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

class BusinessDashboard:
    """Interactive business analytics dashboard"""
    
    def __init__(self):
        self.data_path = '../data/processed'
        self.load_data()
    
    def load_data(self):
        """Load processed data"""
        try:
            self.master_df = pd.read_csv(f'{self.data_path}/master_dataset.csv')
            self.master_df['OrderDate'] = pd.to_datetime(self.master_df['OrderDate'])
            
            # Load additional datasets if available
            try:
                self.customer_analytics = pd.read_csv(f'{self.data_path}/customer_analytics.csv')
            except:
                self.customer_analytics = None
            
            try:
                self.product_performance = pd.read_csv(f'{self.data_path}/product_performance.csv')
            except:
                self.product_performance = None
            
            try:
                self.regional_performance = pd.read_csv(f'{self.data_path}/regional_performance.csv')
            except:
                self.regional_performance = None
                
        except Exception as e:
            st.error(f"Error loading data: {e}")
            self.master_df = pd.DataFrame()
    
    def run(self):
        """Run the dashboard"""
        if self.master_df.empty:
            st.error("No data available. Please run the data pipeline first.")
            return
        
        # Header
        st.markdown('<h1 class="main-header">Business Analytics Dashboard</h1>', unsafe_allow_html=True)
        
        # Sidebar
        self.create_sidebar()
        
        # Main content
        tab1, tab2, tab3, tab4, tab5 = st.tabs(["Overview", "Sales Analysis", "Customer Analysis", "Product Analysis", "Advanced Insights"])
        
        with tab1:
            self.create_overview_tab()
        
        with tab2:
            self.create_sales_tab()
        
        with tab3:
            self.create_customer_tab()
        
        with tab4:
            self.create_product_tab()
        
        with tab5:
            self.create_advanced_insights_tab()
    
    def create_sidebar(self):
        """Create sidebar with filters"""
        st.sidebar.header("Dashboard Controls")
        
        # Date range filter
        min_date = self.master_df['OrderDate'].min().date()
        max_date = self.master_df['OrderDate'].max().date()
        
        date_range = st.sidebar.date_input(
            "Select Date Range",
            value=[min_date, max_date],
            min_value=min_date,
            max_value=max_date
        )
        
        if len(date_range) == 2:
            self.start_date = pd.Timestamp(date_range[0])
            self.end_date = pd.Timestamp(date_range[1])
        else:
            self.start_date = min_date
            self.end_date = max_date
        
        # Region filter
        all_regions = ['All'] + list(self.master_df['Region'].unique())
        selected_region = st.sidebar.selectbox("Select Region", all_regions)
        
        if selected_region == 'All':
            self.selected_region = None
        else:
            self.selected_region = selected_region
        
        # Category filter
        all_categories = ['All'] + list(self.master_df['Category'].unique())
        selected_category = st.sidebar.selectbox("Select Category", all_categories)
        
        if selected_category == 'All':
            self.selected_category = None
        else:
            self.selected_category = selected_category
        
        # Apply filters
        self.apply_filters()
    
    def apply_filters(self):
        """Apply selected filters to data"""
        filtered_df = self.master_df.copy()
        
        # Date filter
        filtered_df = filtered_df[(filtered_df['OrderDate'] >= self.start_date) & 
                                (filtered_df['OrderDate'] <= self.end_date)]
        
        # Region filter
        if self.selected_region:
            filtered_df = filtered_df[filtered_df['Region'] == self.selected_region]
        
        # Category filter
        if self.selected_category:
            filtered_df = filtered_df[filtered_df['Category'] == self.selected_category]
        
        self.filtered_df = filtered_df
    
    def create_overview_tab(self):
        """Create overview tab with KPIs and summary"""
        st.header("Business Overview")
        
        # KPI Cards
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_revenue = self.filtered_df['TotalAmount'].sum()
            st.markdown(f"""
            <div class="kpi-card">
                <h3>Total Revenue</h3>
                <h2>${total_revenue:,.0f}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            total_orders = len(self.filtered_df)
            st.markdown(f"""
            <div class="kpi-card">
                <h3>Total Orders</h3>
                <h2>{total_orders:,}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            avg_order_value = self.filtered_df['TotalAmount'].mean()
            st.markdown(f"""
            <div class="kpi-card">
                <h3>Avg Order Value</h3>
                <h2>${avg_order_value:,.0f}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        with col4:
            total_customers = self.filtered_df['CustomerID'].nunique()
            st.markdown(f"""
            <div class="kpi-card">
                <h3>Total Customers</h3>
                <h2>{total_customers:,}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        # Key Metrics
        st.subheader("Key Performance Metrics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Revenue trend
            monthly_revenue = self.filtered_df.groupby(['Year', 'Month'])['TotalAmount'].sum().reset_index()
            monthly_revenue['Period'] = monthly_revenue['Year'].astype(str) + '-' + monthly_revenue['Month'].astype(str).str.zfill(2)
            
            fig = px.line(monthly_revenue, x='Period', y='TotalAmount', 
                         title='Monthly Revenue Trend',
                         labels={'TotalAmount': 'Revenue ($)', 'Period': 'Month'})
            fig.update_layout(showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Regional distribution
            regional_revenue = self.filtered_df.groupby('Region')['TotalAmount'].sum().reset_index()
            
            fig = px.pie(regional_revenue, values='TotalAmount', names='Region',
                        title='Revenue by Region')
            fig.update_traces(textposition='inside', textinfo='percent+label')
            st.plotly_chart(fig, use_container_width=True)
        
        # Quick Insights
        st.subheader("Quick Insights")
        
        insights = self.generate_quick_insights()
        for insight in insights:
            st.markdown(f'<div class="insight-box">{insight}</div>', unsafe_allow_html=True)
    
    def create_sales_tab(self):
        """Create sales analysis tab"""
        st.header("Sales Analysis")
        
        # Sales metrics
        col1, col2 = st.columns(2)
        
        with col1:
            # Daily sales trend
            daily_sales = self.filtered_df.groupby('OrderDate')['TotalAmount'].sum().reset_index()
            
            fig = px.line(daily_sales, x='OrderDate', y='TotalAmount',
                         title='Daily Sales Trend',
                         labels={'TotalAmount': 'Revenue ($)', 'OrderDate': 'Date'})
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Category performance
            category_sales = self.filtered_df.groupby('Category')['TotalAmount'].sum().reset_index()
            
            fig = px.bar(category_sales, x='Category', y='TotalAmount',
                         title='Revenue by Category',
                         labels={'TotalAmount': 'Revenue ($)'})
            st.plotly_chart(fig, use_container_width=True)
        
        # Top products
        st.subheader("Top Performing Products")
        
        top_products = self.filtered_df.groupby('ProductName')['TotalAmount'].sum().nlargest(10).reset_index()
        
        fig = px.bar(top_products, x='TotalAmount', y='ProductName',
                     orientation='h',
                     title='Top 10 Products by Revenue',
                     labels={'TotalAmount': 'Revenue ($)', 'ProductName': 'Product'})
        st.plotly_chart(fig, use_container_width=True)
        
        # Sales representative performance
        if 'SalesRep' in self.filtered_df.columns:
            st.subheader("Sales Representative Performance")
            
            rep_performance = self.filtered_df.groupby('SalesRep').agg({
                'TotalAmount': 'sum',
                'OrderID': 'count'
            }).reset_index()
            rep_performance.columns = ['SalesRep', 'TotalRevenue', 'OrderCount']
            
            fig = px.scatter(rep_performance, x='OrderCount', y='TotalRevenue',
                             size='TotalRevenue', hover_name='SalesRep',
                             title='Sales Representative Performance',
                             labels={'TotalRevenue': 'Revenue ($)', 'OrderCount': 'Number of Orders'})
            st.plotly_chart(fig, use_container_width=True)
    
    def create_customer_tab(self):
        """Create customer analysis tab"""
        st.header("Customer Analysis")
        
        # Customer metrics
        col1, col2 = st.columns(2)
        
        with col1:
            # Customer segments
            if 'CustomerType' in self.filtered_df.columns:
                customer_types = self.filtered_df.groupby('CustomerType')['CustomerID'].nunique().reset_index()
                
                fig = px.pie(customer_types, values='CustomerID', names='CustomerType',
                            title='Customer Distribution by Type')
                fig.update_traces(textposition='inside', textinfo='percent+label')
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Customer lifetime value distribution
            customer_ltv = self.filtered_df.groupby('CustomerID')['TotalAmount'].sum().reset_index()
            
            fig = px.histogram(customer_ltv, x='TotalAmount',
                             title='Customer Lifetime Value Distribution',
                             labels={'TotalAmount': 'Lifetime Value ($)'})
            st.plotly_chart(fig, use_container_width=True)
        
        # Top customers
        st.subheader("Top Customers by Lifetime Value")
        
        top_customers = customer_ltv.nlargest(10, 'TotalAmount')
        
        fig = px.bar(top_customers, x='TotalAmount', y='CustomerID',
                     orientation='h',
                     title='Top 10 Customers by Lifetime Value',
                     labels={'TotalAmount': 'Lifetime Value ($)', 'CustomerID': 'Customer ID'})
        st.plotly_chart(fig, use_container_width=True)
        
        # Customer acquisition and retention
        st.subheader("Customer Acquisition Trends")
        
        customer_acquisition = self.filtered_df.groupby(['Year', 'Month'])['CustomerID'].nunique().reset_index()
        customer_acquisition['Period'] = customer_acquisition['Year'].astype(str) + '-' + customer_acquisition['Month'].astype(str).str.zfill(2)
        
        fig = px.line(customer_acquisition, x='Period', y='CustomerID',
                     title='Monthly Customer Acquisition',
                     labels={'CustomerID': 'New Customers', 'Period': 'Month'})
        st.plotly_chart(fig, use_container_width=True)
    
    def create_product_tab(self):
        """Create product analysis tab"""
        st.header("Product Analysis")
        
        # Product metrics
        col1, col2 = st.columns(2)
        
        with col1:
            # Product category performance
            if 'Category' in self.filtered_df.columns:
                category_metrics = self.filtered_df.groupby('Category').agg({
                    'TotalAmount': 'sum',
                    'Quantity': 'sum',
                    'ProductID': 'nunique'
                }).reset_index()
                
                fig = px.scatter(category_metrics, x='Quantity', y='TotalAmount',
                               size='ProductID', hover_name='Category',
                               title='Product Category Performance',
                               labels={'TotalAmount': 'Revenue ($)', 'Quantity': 'Units Sold'})
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Price distribution
            if 'UnitPrice' in self.filtered_df.columns:
                fig = px.histogram(self.filtered_df, x='UnitPrice',
                                 title='Product Price Distribution',
                                 labels={'UnitPrice': 'Unit Price ($)'})
                st.plotly_chart(fig, use_container_width=True)
        
        # Product profitability
        st.subheader("Product Profitability Analysis")
        
        if 'Profit' in self.filtered_df.columns:
            product_profit = self.filtered_df.groupby('ProductName')['Profit'].sum().nlargest(10).reset_index()
            
            fig = px.bar(product_profit, x='Profit', y='ProductName',
                        orientation='h',
                        title='Top 10 Most Profitable Products',
                        labels={'Profit': 'Total Profit ($)', 'ProductName': 'Product'})
            st.plotly_chart(fig, use_container_width=True)
        
        # Product sales trends
        st.subheader("Product Sales Trends")
        
        # Select top 5 products for trend analysis
        top_5_products = self.filtered_df.groupby('ProductName')['TotalAmount'].sum().nlargest(5).index
        
        product_trends = []
        for product in top_5_products:
            product_data = self.filtered_df[self.filtered_df['ProductName'] == product]
            monthly_product = product_data.groupby(['Year', 'Month'])['TotalAmount'].sum().reset_index()
            monthly_product['Period'] = monthly_product['Year'].astype(str) + '-' + monthly_product['Month'].astype(str).str.zfill(2)
            monthly_product['Product'] = product
            product_trends.append(monthly_product)
        
        if product_trends:
            trend_df = pd.concat(product_trends)
            
            fig = px.line(trend_df, x='Period', y='TotalAmount', color='Product',
                         title='Sales Trends for Top 5 Products',
                         labels={'TotalAmount': 'Revenue ($)', 'Period': 'Month'})
            st.plotly_chart(fig, use_container_width=True)
    
    def create_advanced_insights_tab(self):
        """Create advanced insights tab"""
        st.header("Advanced Business Insights")
        
        # Cohort analysis
        st.subheader("Customer Cohort Analysis")
        
        cohort_analysis = self.create_cohort_analysis()
        if cohort_analysis is not None:
            fig = px.imshow(cohort_analysis,
                           title="Customer Retention Heatmap",
                           labels=dict(x="Months Since First Purchase", y="Cohort Month", color="Retention Rate"))
            st.plotly_chart(fig, use_container_width=True)
        
        # RFM Analysis
        st.subheader("RFM (Recency, Frequency, Monetary) Analysis")
        
        rfm_analysis = self.create_rfm_analysis()
        if rfm_analysis is not None:
            col1, col2 = st.columns(2)
            
            with col1:
                fig = px.scatter(rfm_analysis, x='Frequency', y='Monetary',
                               color='Segment', size='Recency',
                               title='RFM Customer Segments',
                               labels={'Frequency': 'Purchase Frequency', 'Monetary': 'Total Spending'})
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                segment_counts = rfm_analysis['Segment'].value_counts().reset_index()
                segment_counts.columns = ['Segment', 'Count']
                
                fig = px.pie(segment_counts, values='Count', names='Segment',
                            title='Customer Segment Distribution')
                st.plotly_chart(fig, use_container_width=True)
        
        # Predictive insights
        st.subheader("Predictive Insights")
        
        # Revenue forecast
        forecast_data = self.create_simple_forecast()
        if forecast_data is not None:
            fig = go.Figure()
            
            # Historical data
            fig.add_trace(go.Scatter(
                x=forecast_data['historical']['Date'],
                y=forecast_data['historical']['Revenue'],
                mode='lines+markers',
                name='Historical Revenue',
                line=dict(color='blue')
            ))
            
            # Forecast
            fig.add_trace(go.Scatter(
                x=forecast_data['forecast']['Date'],
                y=forecast_data['forecast']['Revenue'],
                mode='lines+markers',
                name='Forecasted Revenue',
                line=dict(color='red', dash='dash')
            ))
            
            fig.update_layout(title='Revenue Forecast',
                           xaxis_title='Date',
                           yaxis_title='Revenue ($)')
            st.plotly_chart(fig, use_container_width=True)
        
        # Business recommendations
        st.subheader("Business Recommendations")
        
        recommendations = self.generate_recommendations()
        for recommendation in recommendations:
            st.markdown(f'<div class="insight-box">{recommendation}</div>', unsafe_allow_html=True)
    
    def create_cohort_analysis(self):
        """Create cohort analysis"""
        try:
            # Get customer first purchase date
            customer_first_purchase = self.filtered_df.groupby('CustomerID')['OrderDate'].min().reset_index()
            customer_first_purchase.columns = ['CustomerID', 'FirstPurchaseDate']
            
            # Merge with main data
            cohort_data = self.filtered_df.merge(customer_first_purchase, on='CustomerID')
            
            # Calculate cohort period
            cohort_data['CohortMonth'] = cohort_data['FirstPurchaseDate'].dt.to_period('M')
            cohort_data['OrderMonth'] = cohort_data['OrderDate'].dt.to_period('M')
            cohort_data['CohortPeriod'] = (cohort_data['OrderMonth'] - cohort_data['CohortMonth']).apply(attrgetter('n'))
            
            # Create cohort table
            cohort_table = cohort_data.groupby(['CohortMonth', 'CohortPeriod'])['CustomerID'].nunique().reset_index()
            cohort_table = cohort_table.pivot(index='CohortMonth', columns='CohortPeriod', values='CustomerID')
            
            # Calculate retention rates
            cohort_sizes = cohort_table.iloc[:, 0]
            retention_table = cohort_table.divide(cohort_sizes, axis=0)
            
            return retention_table
            
        except Exception as e:
            st.error(f"Error in cohort analysis: {e}")
            return None
    
    def create_rfm_analysis(self):
        """Create RFM analysis"""
        try:
            # Calculate RFM metrics
            current_date = self.filtered_df['OrderDate'].max()
            
            rfm = self.filtered_df.groupby('CustomerID').agg({
                'OrderDate': lambda x: (current_date - x.max()).days,  # Recency
                'OrderID': 'count',  # Frequency
                'TotalAmount': 'sum'  # Monetary
            }).reset_index()
            
            rfm.columns = ['CustomerID', 'Recency', 'Frequency', 'Monetary']
            
            # Create segments
            rfm['R_Score'] = pd.qcut(rfm['Recency'], 5, labels=[5, 4, 3, 2, 1])
            rfm['F_Score'] = pd.qcut(rfm['Frequency'].rank(method='first'), 5, labels=[1, 2, 3, 4, 5])
            rfm['M_Score'] = pd.qcut(rfm['Monetary'], 5, labels=[1, 2, 3, 4, 5])
            
            # Create RFM segment
            rfm['RFM_Score'] = rfm['R_Score'].astype(str) + rfm['F_Score'].astype(str) + rfm['M_Score'].astype(str)
            
            # Create segment names
            rfm['Segment'] = 'Other'
            rfm.loc[rfm['RFM_Score'].isin(['555', '554', '544', '545', '454', '455', '445']), 'Segment'] = 'Champions'
            rfm.loc[rfm['RFM_Score'].isin(['543', '444', '435', '355', '354', '345', '344', '335']), 'Segment'] = 'Loyal Customers'
            rfm.loc[rfm['RFM_Score'].isin(['512', '511', '422', '421', '412', '411', '311']), 'Segment'] = 'Potential Loyalist'
            rfm.loc[rfm['RFM_Score'].isin(['334', '333', '332', '323', '322', '233', '232', '223', '222', '132', '123', '122', '212', '211']), 'Segment'] = 'Needs Attention'
            rfm.loc[rfm['RFM_Score'].isin(['155', '154', '144', '214', '215', '115', '114', '113']), 'Segment'] = 'Cannot Lose Them'
            rfm.loc[rfm['RFM_Score'].isin(['331', '321', '231', '241', '251']), 'Segment'] = 'At Risk'
            rfm.loc[rfm['RFM_Score'].isin(['533', '532', '523', '522', '521', '512', '511']), 'Segment'] = 'New Customers'
            rfm.loc[rfm['RFM_Score'].isin(['553', '551', '552', '541', '542', '531', '521', '511', '425', '424', '423', '415', '414', '413']), 'Segment'] = 'Promising'
            rfm.loc[rfm['RFM_Score'].isin(['244', '243', '234', '233', '224', '223', '143', '142', '134', '133', '124', '123']), 'Segment'] = 'Hibernating'
            
            return rfm
            
        except Exception as e:
            st.error(f"Error in RFM analysis: {e}")
            return None
    
    def create_simple_forecast(self):
        """Create simple revenue forecast"""
        try:
            # Prepare data
            daily_revenue = self.filtered_df.groupby('OrderDate')['TotalAmount'].sum().reset_index()
            daily_revenue = daily_revenue.sort_values('OrderDate')
            
            # Simple linear forecast
            from sklearn.linear_model import LinearRegression
            
            # Use last 30 days for training
            recent_data = daily_revenue.tail(30)
            X = np.array(range(len(recent_data))).reshape(-1, 1)
            y = recent_data['TotalAmount'].values
            
            model = LinearRegression()
            model.fit(X, y)
            
            # Generate forecast for next 30 days
            forecast_X = np.array(range(len(recent_data), len(recent_data) + 30)).reshape(-1, 1)
            forecast_values = model.predict(forecast_X)
            
            # Create forecast dates
            last_date = recent_data['OrderDate'].max()
            forecast_dates = [last_date + pd.Timedelta(days=i+1) for i in range(30)]
            
            return {
                'historical': {
                    'Date': recent_data['OrderDate'].tolist(),
                    'Revenue': recent_data['TotalAmount'].tolist()
                },
                'forecast': {
                    'Date': forecast_dates,
                    'Revenue': forecast_values.tolist()
                }
            }
            
        except Exception as e:
            st.error(f"Error in forecast: {e}")
            return None
    
    def generate_quick_insights(self):
        """Generate quick insights"""
        insights = []
        
        try:
            # Revenue trend
            if len(self.filtered_df) > 0:
                total_revenue = self.filtered_df['TotalAmount'].sum()
                avg_order_value = self.filtered_df['TotalAmount'].mean()
                
                insights.append(f"Total revenue of ${total_revenue:,.0f} with average order value of ${avg_order_value:,.0f}")
                
                # Top performer
                top_region = self.filtered_df.groupby('Region')['TotalAmount'].sum().idxmax()
                insights.append(f"Best performing region: {top_region}")
                
                # Product insight
                top_product = self.filtered_df.groupby('ProductName')['TotalAmount'].sum().idxmax()
                insights.append(f"Best selling product: {top_product}")
                
        except Exception as e:
            insights.append("Insights generation temporarily unavailable")
        
        return insights
    
    def generate_recommendations(self):
        """Generate business recommendations"""
        recommendations = []
        
        try:
            # Analyze data and generate recommendations
            if len(self.filtered_df) > 0:
                # Customer recommendation
                high_value_customers = self.filtered_df.groupby('CustomerID')['TotalAmount'].sum()
                top_10_percent = high_value_customers.quantile(0.9)
                top_customers_count = len(high_value_customers[high_value_customers >= top_10_percent])
                
                recommendations.append(f"Focus on retaining {top_customers_count} high-value customers who generate significant revenue")
                
                # Product recommendation
                category_performance = self.filtered_df.groupby('Category')['TotalAmount'].sum()
                if len(category_performance) > 1:
                    best_category = category_performance.idxmax()
                    worst_category = category_performance.idxmin()
                    recommendations.append(f"Leverage success in {best_category} category to improve performance in {worst_category} category")
                
                # Regional recommendation
                regional_performance = self.filtered_df.groupby('Region')['TotalAmount'].sum()
                if len(regional_performance) > 1:
                    best_region = regional_performance.idxmax()
                    recommendations.append(f"Expand successful strategies from {best_region} region to underperforming regions")
                
        except Exception as e:
            recommendations.append("Recommendations generation temporarily unavailable")
        
        return recommendations

def main():
    """Main function to run the dashboard"""
    dashboard = BusinessDashboard()
    dashboard.run()

if __name__ == "__main__":
    main()

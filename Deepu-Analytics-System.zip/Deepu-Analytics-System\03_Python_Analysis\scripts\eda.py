#!/usr/bin/env python3
"""
Exploratory Data Analysis (EDA) Script for Business Analytics System
Comprehensive statistical analysis and insights generation
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import logging
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('eda_analysis.log'),
        logging.StreamHandler()
    ]
)

class BusinessEDA:
    """Comprehensive EDA class for business analytics"""
    
    def __init__(self, data_dir='../data', output_dir='../03_Python_Analysis/outputs'):
        self.data_dir = data_dir
        self.cleaned_dir = os.path.join(data_dir, 'cleaned')
        self.processed_dir = os.path.join(data_dir, 'processed')
        self.output_dir = output_dir
        
        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Set up plotting style
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
        logging.info("BusinessEDA initialized")
    
    def load_data(self):
        """Load cleaned datasets"""
        try:
            self.sales_df = pd.read_csv(os.path.join(self.cleaned_dir, 'sales_cleaned.csv'))
            self.customers_df = pd.read_csv(os.path.join(self.cleaned_dir, 'customers_cleaned.csv'))
            self.products_df = pd.read_csv(os.path.join(self.cleaned_dir, 'products_cleaned.csv'))
            
            # Convert date columns
            self.sales_df['OrderDate'] = pd.to_datetime(self.sales_df['OrderDate'])
            self.customers_df['JoinDate'] = pd.to_datetime(self.customers_df['JoinDate'])
            self.products_df['LaunchDate'] = pd.to_datetime(self.products_df['LaunchDate'])
            
            logging.info("Datasets loaded successfully")
            return True
            
        except Exception as e:
            logging.error(f"Error loading datasets: {e}")
            return False
    
    def sales_analysis(self):
        """Comprehensive sales analysis"""
        try:
            logging.info("Starting sales analysis")
            
            # 1. Revenue Analysis
            revenue_metrics = {
                'total_revenue': self.sales_df['TotalAmount'].sum(),
                'avg_order_value': self.sales_df['TotalAmount'].mean(),
                'median_order_value': self.sales_df['TotalAmount'].median(),
                'total_orders': len(self.sales_df),
                'total_quantity': self.sales_df['Quantity'].sum()
            }
            
            # 2. Time Series Analysis
            daily_sales = self.sales_df.groupby('OrderDate')['TotalAmount'].sum().reset_index()
            monthly_sales = self.sales_df.groupby(['Year', 'Month'])['TotalAmount'].sum().reset_index()
            monthly_sales['Period'] = monthly_sales['Year'].astype(str) + '-' + monthly_sales['Month'].astype(str).str.zfill(2)
            
            # 3. Regional Analysis
            regional_sales = self.sales_df.groupby('Region').agg({
                'TotalAmount': ['sum', 'mean', 'count'],
                'Quantity': 'sum'
            }).round(2)
            
            # 4. Category Analysis
            category_sales = self.sales_df.groupby('Category').agg({
                'TotalAmount': ['sum', 'mean', 'count'],
                'Quantity': 'sum'
            }).round(2)
            
            # 5. Product Performance
            product_performance = self.sales_df.groupby('ProductName').agg({
                'TotalAmount': 'sum',
                'Quantity': 'sum',
                'OrderID': 'count'
            }).rename(columns={'OrderID': 'order_count'}).sort_values('TotalAmount', ascending=False)
            
            # 6. Customer Analysis
            customer_analysis = self.sales_df.groupby('CustomerID').agg({
                'TotalAmount': ['sum', 'mean', 'count'],
                'OrderDate': ['min', 'max']
            }).round(2)
            
            # Create visualizations
            self._create_sales_visualizations(daily_sales, monthly_sales, regional_sales, category_sales)
            
            # Generate insights
            insights = self._generate_sales_insights(revenue_metrics, regional_sales, category_sales)
            
            logging.info("Sales analysis completed")
            return insights
            
        except Exception as e:
            logging.error(f"Error in sales analysis: {e}")
            return None
    
    def customer_analysis(self):
        """Comprehensive customer analysis"""
        try:
            logging.info("Starting customer analysis")
            
            # 1. Customer Segmentation
            customer_segments = self.customers_df['CustomerType'].value_counts()
            
            # 2. Geographic Distribution
            geo_distribution = self.customers_df.groupby(['State', 'City']).size().reset_index(name='customer_count')
            
            # 3. Customer Age Analysis
            customer_age_stats = {
                'avg_customer_age_years': self.customers_df['CustomerAgeYears'].mean(),
                'median_customer_age_years': self.customers_df['CustomerAgeYears'].median(),
                'new_customers_30_days': (self.customers_df['CustomerAge'] <= 30).sum(),
                'loyal_customers_1_year': (self.customers_df['CustomerAge'] >= 365).sum()
            }
            
            # 4. Customer Lifetime Value
            customer_ltv = self.sales_df.groupby('CustomerID')['TotalAmount'].sum().sort_values(ascending=False)
            
            # 5. Purchase Frequency Analysis
            purchase_frequency = self.sales_df.groupby('CustomerID').size().value_counts().sort_index()
            
            # Create visualizations
            self._create_customer_visualizations(customer_segments, geo_distribution, customer_ltv, purchase_frequency)
            
            # Generate insights
            insights = self._generate_customer_insights(customer_segments, customer_age_stats, customer_ltv)
            
            logging.info("Customer analysis completed")
            return insights
            
        except Exception as e:
            logging.error(f"Error in customer analysis: {e}")
            return None
    
    def product_analysis(self):
        """Comprehensive product analysis"""
        try:
            logging.info("Starting product analysis")
            
            # 1. Product Category Performance
            category_performance = self.products_df.groupby('Category').agg({
                'UnitPrice': ['mean', 'median'],
                'UnitCost': 'mean',
                'ProfitMargin': 'mean'
            }).round(2)
            
            # 2. Price Analysis
            price_analysis = {
                'avg_unit_price': self.products_df['UnitPrice'].mean(),
                'median_unit_price': self.products_df['UnitPrice'].median(),
                'price_range': {
                    'min': self.products_df['UnitPrice'].min(),
                    'max': self.products_df['UnitPrice'].max()
                }
            }
            
            # 3. Profit Margin Analysis
            profit_analysis = {
                'avg_profit_margin': self.products_df['ProfitMargin'].mean(),
                'median_profit_margin': self.products_df['ProfitMargin'].median(),
                'high_margin_products': (self.products_df['ProfitMargin'] > 50).sum(),
                'low_margin_products': (self.products_df['ProfitMargin'] < 20).sum()
            }
            
            # 4. Product Age Analysis
            product_age_stats = {
                'avg_product_age_days': self.products_df['ProductAge'].mean(),
                'new_products_30_days': (self.products_df['ProductAge'] <= 30).sum(),
                'mature_products_1_year': (self.products_df['ProductAge'] >= 365).sum()
            }
            
            # 5. Price Category Distribution
            price_category_dist = self.products_df['PriceCategory'].value_counts()
            
            # Create visualizations
            self._create_product_visualizations(category_performance, price_category_dist)
            
            # Generate insights
            insights = self._generate_product_insights(category_performance, profit_analysis, product_age_stats)
            
            logging.info("Product analysis completed")
            return insights
            
        except Exception as e:
            logging.error(f"Error in product analysis: {e}")
            return None
    
    def correlation_analysis(self):
        """Correlation and relationship analysis"""
        try:
            logging.info("Starting correlation analysis")
            
            # Create master dataset for correlation analysis
            master_df = self.sales_df.merge(self.customers_df, on='CustomerID', how='left')
            master_df = master_df.merge(self.products_df, on='ProductID', how='left')
            
            # Select numeric columns for correlation
            numeric_cols = ['Quantity', 'UnitPrice_x', 'Discount', 'TotalAmount', 'Profit', 
                          'CustomerAge', 'UnitCost', 'ProfitMargin']
            
            correlation_matrix = master_df[numeric_cols].corr()
            
            # Create correlation heatmap
            plt.figure(figsize=(12, 8))
            sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0, 
                       square=True, linewidths=0.5)
            plt.title('Correlation Matrix - Business Metrics')
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'correlation_heatmap.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
            # Find strong correlations
            strong_correlations = []
            for i in range(len(correlation_matrix.columns)):
                for j in range(i+1, len(correlation_matrix.columns)):
                    corr_value = correlation_matrix.iloc[i, j]
                    if abs(corr_value) > 0.5:  # Strong correlation threshold
                        strong_correlations.append({
                            'variable1': correlation_matrix.columns[i],
                            'variable2': correlation_matrix.columns[j],
                            'correlation': corr_value
                        })
            
            logging.info("Correlation analysis completed")
            return strong_correlations
            
        except Exception as e:
            logging.error(f"Error in correlation analysis: {e}")
            return None
    
    def _create_sales_visualizations(self, daily_sales, monthly_sales, regional_sales, category_sales):
        """Create sales-related visualizations"""
        try:
            # 1. Daily Sales Trend
            plt.figure(figsize=(14, 6))
            plt.plot(daily_sales['OrderDate'], daily_sales['TotalAmount'], marker='o', linewidth=2)
            plt.title('Daily Sales Trend')
            plt.xlabel('Date')
            plt.ylabel('Revenue ($)')
            plt.xticks(rotation=45)
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'daily_sales_trend.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
            # 2. Monthly Sales Bar Chart
            plt.figure(figsize=(12, 6))
            bars = plt.bar(monthly_sales['Period'], monthly_sales['TotalAmount'], color='skyblue', alpha=0.8)
            plt.title('Monthly Sales Revenue')
            plt.xlabel('Period')
            plt.ylabel('Revenue ($)')
            plt.xticks(rotation=45)
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'${height:,.0f}', ha='center', va='bottom')
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'monthly_sales.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
            # 3. Regional Sales Pie Chart
            plt.figure(figsize=(10, 8))
            regional_totals = regional_sales[('TotalAmount', 'sum')]
            colors = plt.cm.Set3(np.linspace(0, 1, len(regional_totals)))
            plt.pie(regional_totals.values, labels=regional_totals.index, autopct='%1.1f%%', 
                   colors=colors, startangle=90)
            plt.title('Revenue Distribution by Region')
            plt.axis('equal')
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'regional_sales_pie.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
            # 4. Category Performance
            plt.figure(figsize=(12, 6))
            category_totals = category_sales[('TotalAmount', 'sum')]
            bars = plt.bar(category_totals.index, category_totals.values, color='lightcoral', alpha=0.8)
            plt.title('Revenue by Product Category')
            plt.xlabel('Category')
            plt.ylabel('Revenue ($)')
            
            # Add value labels
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'${height:,.0f}', ha='center', va='bottom')
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'category_sales.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating sales visualizations: {e}")
    
    def _create_customer_visualizations(self, customer_segments, geo_distribution, customer_ltv, purchase_frequency):
        """Create customer-related visualizations"""
        try:
            # 1. Customer Segments
            plt.figure(figsize=(10, 6))
            colors = ['gold', 'lightcoral', 'lightskyblue', 'lightgreen']
            wedges, texts, autotexts = plt.pie(customer_segments.values, labels=customer_segments.index, 
                                              autopct='%1.1f%%', colors=colors, startangle=90)
            plt.title('Customer Type Distribution')
            plt.axis('equal')
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'customer_segments.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
            # 2. Top 10 Customers by LTV
            plt.figure(figsize=(14, 6))
            top_10_customers = customer_ltv.head(10)
            bars = plt.bar(range(len(top_10_customers)), top_10_customers.values, color='royalblue', alpha=0.8)
            plt.title('Top 10 Customers by Lifetime Value')
            plt.xlabel('Customer ID')
            plt.ylabel('Lifetime Value ($)')
            plt.xticks(range(len(top_10_customers)), top_10_customers.index, rotation=45)
            
            # Add value labels
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'${height:,.0f}', ha='center', va='bottom')
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'top_customers_ltv.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
            # 3. Purchase Frequency Distribution
            plt.figure(figsize=(12, 6))
            plt.bar(purchase_frequency.index, purchase_frequency.values, color='orange', alpha=0.8)
            plt.title('Purchase Frequency Distribution')
            plt.xlabel('Number of Purchases')
            plt.ylabel('Number of Customers')
            plt.yscale('log')
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'purchase_frequency.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating customer visualizations: {e}")
    
    def _create_product_visualizations(self, category_performance, price_category_dist):
        """Create product-related visualizations"""
        try:
            # 1. Profit Margin by Category
            plt.figure(figsize=(10, 6))
            margins = category_performance[('ProfitMargin', 'mean')]
            bars = plt.bar(margins.index, margins.values, color='green', alpha=0.8)
            plt.title('Average Profit Margin by Product Category')
            plt.xlabel('Category')
            plt.ylabel('Profit Margin (%)')
            
            # Add value labels
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'{height:.1f}%', ha='center', va='bottom')
            
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'profit_margin_by_category.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
            # 2. Price Category Distribution
            plt.figure(figsize=(10, 6))
            colors = ['red', 'orange', 'blue', 'purple']
            wedges, texts, autotexts = plt.pie(price_category_dist.values, labels=price_category_dist.index, 
                                              autopct='%1.1f%%', colors=colors, startangle=90)
            plt.title('Product Distribution by Price Category')
            plt.axis('equal')
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, 'price_category_distribution.png'), dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            logging.error(f"Error creating product visualizations: {e}")
    
    def _generate_sales_insights(self, revenue_metrics, regional_sales, category_sales):
        """Generate sales insights"""
        insights = []
        
        # Revenue insights
        insights.append(f"Total Revenue: ${revenue_metrics['total_revenue']:,.2f}")
        insights.append(f"Average Order Value: ${revenue_metrics['avg_order_value']:,.2f}")
        insights.append(f"Total Orders Processed: {revenue_metrics['total_orders']:,}")
        
        # Regional insights
        top_region = regional_sales[('TotalAmount', 'sum')].idxmax()
        insights.append(f"Top Performing Region: {top_region}")
        
        # Category insights
        top_category = category_sales[('TotalAmount', 'sum')].idxmax()
        insights.append(f"Best Performing Category: {top_category}")
        
        return insights
    
    def _generate_customer_insights(self, customer_segments, customer_age_stats, customer_ltv):
        """Generate customer insights"""
        insights = []
        
        # Customer type insights
        insights.append(f"Total Customers: {customer_segments.sum():,}")
        insights.append(f"Enterprise Customers: {customer_segments.get('Enterprise', 0):,}")
        
        # Customer age insights
        insights.append(f"Average Customer Age: {customer_age_stats['avg_customer_age_years']:.1f} years")
        insights.append(f"New Customers (30 days): {customer_age_stats['new_customers_30_days']}")
        
        # LTV insights
        insights.append(f"Average Customer Lifetime Value: ${customer_ltv.mean():,.2f}")
        insights.append(f"Top Customer LTV: ${customer_ltv.iloc[0]:,.2f}")
        
        return insights
    
    def _generate_product_insights(self, category_performance, profit_analysis, product_age_stats):
        """Generate product insights"""
        insights = []
        
        # Profit margin insights
        insights.append(f"Average Profit Margin: {profit_analysis['avg_profit_margin']:.1f}%")
        insights.append(f"High Margin Products: {profit_analysis['high_margin_products']}")
        
        # Product age insights
        insights.append(f"Average Product Age: {product_age_stats['avg_product_age_days']:.0f} days")
        insights.append(f"New Products (30 days): {product_age_stats['new_products_30_days']}")
        
        return insights
    
    def generate_eda_report(self, sales_insights, customer_insights, product_insights, correlations):
        """Generate comprehensive EDA report"""
        try:
            report = {
                'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'sales_insights': sales_insights,
                'customer_insights': customer_insights,
                'product_insights': product_insights,
                'strong_correlations': correlations,
                'data_summary': {
                    'total_sales_records': len(self.sales_df),
                    'total_customers': len(self.customers_df),
                    'total_products': len(self.products_df),
                    'analysis_period': {
                        'start': self.sales_df['OrderDate'].min().strftime('%Y-%m-%d'),
                        'end': self.sales_df['OrderDate'].max().strftime('%Y-%m-%d')
                    }
                }
            }
            
            # Save report as JSON
            import json
            report_path = os.path.join(self.output_dir, 'eda_report.json')
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            # Save report as text
            text_report_path = os.path.join(self.output_dir, 'eda_report.txt')
            with open(text_report_path, 'w') as f:
                f.write("BUSINESS ANALYTICS - EXPLORATORY DATA ANALYSIS REPORT\n")
                f.write("=" * 60 + "\n\n")
                f.write(f"Analysis Date: {report['analysis_date']}\n\n")
                
                f.write("SALES INSIGHTS:\n")
                f.write("-" * 20 + "\n")
                for insight in sales_insights:
                    f.write(f"  {insight}\n")
                f.write("\n")
                
                f.write("CUSTOMER INSIGHTS:\n")
                f.write("-" * 20 + "\n")
                for insight in customer_insights:
                    f.write(f"  {insight}\n")
                f.write("\n")
                
                f.write("PRODUCT INSIGHTS:\n")
                f.write("-" * 20 + "\n")
                for insight in product_insights:
                    f.write(f"  {insight}\n")
                f.write("\n")
                
                f.write("STRONG CORRELATIONS:\n")
                f.write("-" * 20 + "\n")
                for corr in correlations:
                    f.write(f"  {corr['variable1']} - {corr['variable2']}: {corr['correlation']:.3f}\n")
            
            logging.info("EDA report generated successfully")
            return report
            
        except Exception as e:
            logging.error(f"Error generating EDA report: {e}")
            return None

def main():
    """Main execution function"""
    print("Starting Exploratory Data Analysis...")
    
    # Initialize EDA
    eda = BusinessEDA()
    
    # Load data
    if not eda.load_data():
        print("Failed to load data. Exiting...")
        return
    
    # Perform analyses
    sales_insights = eda.sales_analysis()
    customer_insights = eda.customer_analysis()
    product_insights = eda.product_analysis()
    correlations = eda.correlation_analysis()
    
    # Generate comprehensive report
    if all([sales_insights, customer_insights, product_insights]):
        eda.generate_eda_report(sales_insights, customer_insights, product_insights, correlations)
        print("EDA completed successfully!")
        print(f"Visualizations and reports saved to: {eda.output_dir}")
    else:
        print("EDA analysis failed. Check logs for details.")

if __name__ == "__main__":
    main()

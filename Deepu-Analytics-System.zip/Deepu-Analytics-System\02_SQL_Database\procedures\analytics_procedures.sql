-- Stored Procedures for Business Analytics
-- Reusable procedures for common analytical tasks

-- Procedure 1: Calculate Monthly Sales Performance
DELIMITER //
CREATE PROCEDURE GetMonthlySalesPerformance(IN year_param INT)
BEGIN
    SELECT 
        MONTHNAME(o.order_date) AS month_name,
        MONTH(o.order_date) AS month_number,
        SUM(line_total) AS total_revenue,
        COUNT(DISTINCT o.order_id) AS total_orders,
        AVG(line_total) AS avg_order_value,
        SUM(od.quantity) AS total_quantity,
        SUM(line_total) - LAG(SUM(line_total), 1) OVER (ORDER BY MONTH(o.order_date)) AS revenue_change,
        CASE 
            WHEN LAG(SUM(line_total), 1) OVER (ORDER BY MONTH(o.order_date)) > 0
            THEN ((SUM(line_total) - LAG(SUM(line_total), 1) OVER (ORDER BY MONTH(o.order_date))) / 
                  LAG(SUM(line_total), 1) OVER (ORDER BY MONTH(o.order_date))) * 100
            ELSE NULL
        END AS growth_percentage
    FROM orders o
    JOIN order_details od ON o.order_id = od.order_id
    WHERE YEAR(o.order_date) = year_param AND o.order_status = 'Delivered'
    GROUP BY MONTH(o.order_date), MONTHNAME(o.order_date)
    ORDER BY month_number;
END //
DELIMITER ;

-- Procedure 2: Get Top Performing Products
DELIMITER //
CREATE PROCEDURE GetTopProducts(IN limit_param INT, IN start_date DATE, IN end_date DATE)
BEGIN
    SELECT 
        p.product_id,
        p.product_name,
        cat.category_name,
        SUM(od.quantity) AS total_quantity,
        SUM(line_total) AS total_revenue,
        AVG(od.unit_price) AS avg_selling_price,
        SUM(line_total) - (SUM(od.quantity) * p.unit_cost) AS total_profit,
        (SUM(line_total) - (SUM(od.quantity) * p.unit_cost)) / SUM(line_total) * 100 AS profit_margin,
        COUNT(DISTINCT od.order_id) AS times_ordered,
        AVG(od.quantity) AS avg_quantity_per_order
    FROM products p
    JOIN order_details od ON p.product_id = od.product_id
    JOIN categories cat ON p.category_id = cat.category_id
    JOIN orders o ON od.order_id = o.order_id
    WHERE o.order_date BETWEEN start_date AND end_date AND o.order_status = 'Delivered'
    GROUP BY p.product_id, p.product_name, cat.category_name, p.unit_cost
    ORDER BY total_revenue DESC
    LIMIT limit_param;
END //
DELIMITER ;

-- Procedure 3: Customer Segmentation Report
DELIMITER //
CREATE PROCEDURE GetCustomerSegmentation()
BEGIN
    WITH customer_stats AS (
        SELECT 
            c.customer_id,
            c.company_name,
            c.customer_type,
            COUNT(DISTINCT o.order_id) AS order_count,
            SUM(line_total) AS total_revenue,
            AVG(line_total) AS avg_order_value,
            MIN(o.order_date) AS first_order,
            MAX(o.order_date) AS last_order,
            DATEDIFF(MAX(o.order_date), MIN(o.order_date)) AS customer_age_days,
            CASE 
                WHEN MAX(o.order_date) >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) THEN 'Active'
                WHEN MAX(o.order_date) >= DATE_SUB(CURRENT_DATE, INTERVAL 90 DAY) THEN 'Recent'
                ELSE 'Inactive'
            END AS activity_status
        FROM customers c
        LEFT JOIN orders o ON c.customer_id = o.customer_id
        LEFT JOIN order_details od ON o.order_id = od.order_id
        WHERE o.order_status = 'Delivered' OR o.order_id IS NULL
        GROUP BY c.customer_id, c.company_name, c.customer_type
    )
    SELECT 
        customer_type,
        activity_status,
        COUNT(*) AS customer_count,
        SUM(order_count) AS total_orders,
        SUM(total_revenue) AS total_revenue,
        AVG(avg_order_value) AS avg_order_value,
        AVG(customer_age_days) AS avg_customer_age,
        SUM(total_revenue) / COUNT(*) AS revenue_per_customer,
        CASE 
            WHEN SUM(total_revenue) > 100000 THEN 'High Value Segment'
            WHEN SUM(total_revenue) > 50000 THEN 'Medium Value Segment'
            ELSE 'Low Value Segment'
        END AS segment_value
    FROM customer_stats
    GROUP BY customer_type, activity_status
    ORDER BY total_revenue DESC;
END //
DELIMITER ;

-- Procedure 4: Regional Performance Comparison
DELIMITER //
CREATE PROCEDURE GetRegionalPerformance(IN start_date DATE, IN end_date DATE)
BEGIN
    SELECT 
        r.region_name,
        COUNT(DISTINCT c.customer_id) AS customer_count,
        COUNT(DISTINCT o.order_id) AS order_count,
        SUM(line_total) AS total_revenue,
        AVG(line_total) AS avg_order_value,
        SUM(od.quantity) AS total_quantity,
        SUM(line_total) / COUNT(DISTINCT c.customer_id) AS revenue_per_customer,
        COUNT(DISTINCT sr.rep_id) AS sales_rep_count,
        AVG(sr.base_salary) AS avg_base_salary,
        (SUM(line_total) / (SELECT SUM(line_total) FROM orders o2 
                            JOIN order_details od2 ON o2.order_id = od2.order_id 
                            WHERE o2.order_date BETWEEN start_date AND end_date 
                            AND o2.order_status = 'Delivered') * 100) AS market_share_percentage
    FROM regions r
    LEFT JOIN orders o ON r.region_id = o.region_id
    LEFT JOIN order_details od ON o.order_id = od.order_id
    LEFT JOIN customers c ON o.customer_id = c.customer_id
    LEFT JOIN sales_reps sr ON r.region_id = sr.region_id
    WHERE (o.order_date BETWEEN start_date AND end_date OR o.order_id IS NULL) 
          AND (o.order_status = 'Delivered' OR o.order_id IS NULL)
    GROUP BY r.region_id, r.region_name
    ORDER BY total_revenue DESC;
END //
DELIMITER ;

-- Procedure 5: Sales Performance Dashboard Data
DELIMITER //
CREATE PROCEDURE GetSalesDashboardData(IN dashboard_date DATE)
BEGIN
    -- Overall Metrics
    SELECT 'total_revenue' AS metric, SUM(line_total) AS value
    FROM orders o
    JOIN order_details od ON o.order_id = od.order_id
    WHERE o.order_status = 'Delivered' AND o.order_date <= dashboard_date
    
    UNION ALL
    
    SELECT 'total_orders' AS metric, COUNT(DISTINCT o.order_id) AS value
    FROM orders o
    WHERE o.order_status = 'Delivered' AND o.order_date <= dashboard_date
    
    UNION ALL
    
    SELECT 'total_customers' AS metric, COUNT(DISTINCT o.customer_id) AS value
    FROM orders o
    WHERE o.order_status = 'Delivered' AND o.order_date <= dashboard_date
    
    UNION ALL
    
    SELECT 'avg_order_value' AS metric, AVG(line_total) AS value
    FROM orders o
    JOIN order_details od ON o.order_id = od.order_id
    WHERE o.order_status = 'Delivered' AND o.order_date <= dashboard_date;
END //
DELIMITER ;

-- Procedure 6: Inventory Analysis
DELIMITER //
CREATE PROCEDURE GetInventoryAnalysis()
BEGIN
    SELECT 
        p.product_id,
        p.product_name,
        cat.category_name,
        p.unit_cost,
        p.unit_price,
        p.reorder_level,
        COALESCE(SUM(od.quantity), 0) AS units_sold,
        COALESCE(SUM(line_total), 0) AS total_revenue,
        CASE 
            WHEN COALESCE(SUM(od.quantity), 0) = 0 THEN 'No Sales'
            WHEN COALESCE(SUM(od.quantity), 0) < p.reorder_level THEN 'Low Stock'
            WHEN COALESCE(SUM(od.quantity), 0) >= p.reorder_level * 2 THEN 'High Demand'
            ELSE 'Normal'
        END AS stock_status,
        CASE 
            WHEN COALESCE(SUM(od.quantity), 0) = 0 THEN 'Not Selling'
            WHEN COALESCE(SUM(od.quantity), 0) < 10 THEN 'Slow Moving'
            WHEN COALESCE(SUM(od.quantity), 0) < 50 THEN 'Medium Moving'
            ELSE 'Fast Moving'
        END AS movement_status,
        (p.unit_price - p.unit_cost) / p.unit_price * 100 AS gross_margin_percentage
    FROM products p
    LEFT JOIN categories cat ON p.category_id = cat.category_id
    LEFT JOIN order_details od ON p.product_id = od.product_id
    LEFT JOIN orders o ON od.order_id = o.order_id AND o.order_status = 'Delivered'
    GROUP BY p.product_id, p.product_name, cat.category_name, p.unit_cost, p.unit_price, p.reorder_level
    ORDER BY units_sold DESC;
END //
DELIMITER ;

-- Procedure 7: Customer Lifetime Value Calculation
DELIMITER //
CREATE PROCEDURE CalculateCustomerLifetimeValue(IN customer_id_param VARCHAR(10))
BEGIN
    WITH customer_purchases AS (
        SELECT 
            c.customer_id,
            c.company_name,
            c.customer_type,
            COUNT(DISTINCT o.order_id) AS order_frequency,
            SUM(line_total) AS total_revenue,
            AVG(line_total) AS avg_order_value,
            MIN(o.order_date) AS first_purchase,
            MAX(o.order_date) AS last_purchase,
            DATEDIFF(MAX(o.order_date), MIN(o.order_date)) AS customer_age_days,
            AVG(DATEDIFF(o.order_date, LAG(o.order_date) OVER (ORDER BY o.order_date))) AS avg_days_between_orders
        FROM customers c
        JOIN orders o ON c.customer_id = o.customer_id
        JOIN order_details od ON o.order_id = od.order_id
        WHERE c.customer_id = customer_id_param AND o.order_status = 'Delivered'
        GROUP BY c.customer_id, c.company_name, c.customer_type
    )
    SELECT 
        customer_id,
        company_name,
        customer_type,
        order_frequency,
        total_revenue AS clv_historical,
        avg_order_value,
        customer_age_days,
        CASE 
            WHEN avg_days_between_orders > 0 
            THEN (365 / avg_days_between_orders) * avg_order_value * 3  -- 3-year projected CLV
            ELSE total_revenue
        END AS projected_clv_3_years,
        CASE 
            WHEN customer_age_days > 0 
            THEN (total_revenue / customer_age_days) * 365  -- Annualized value
            ELSE 0
        END AS annualized_value,
        CASE 
            WHEN order_frequency > 0 
            THEN customer_age_days / order_frequency
            ELSE 0
        END AS avg_customer_lifecycle_days
    FROM customer_purchases;
END //
DELIMITER ;

-- Procedure 8: Discount Effectiveness Analysis
DELIMITER //
CREATE PROCEDURE AnalyzeDiscountEffectiveness()
BEGIN
    SELECT 
        CASE 
            WHEN od.discount = 0 THEN 'No Discount'
            WHEN od.discount <= 0.05 THEN 'Low (1-5%)'
            WHEN od.discount <= 0.10 THEN 'Medium (6-10%)'
            ELSE 'High (>10%)'
        END AS discount_level,
        COUNT(DISTINCT od.order_detail_id) AS transaction_count,
        SUM(od.quantity) AS total_quantity,
        SUM(line_total) AS total_revenue,
        AVG(od.unit_price) AS avg_unit_price,
        AVG(od.discount) * 100 AS avg_discount_percentage,
        SUM(line_total) - SUM(od.quantity * p.unit_cost) AS total_profit,
        (SUM(line_total) - SUM(od.quantity * p.unit_cost)) / SUM(line_total) * 100 AS profit_margin,
        COUNT(DISTINCT od.order_id) AS unique_orders,
        CASE 
            WHEN COUNT(DISTINCT od.order_id) > 0 
            THEN SUM(line_total) / COUNT(DISTINCT od.order_id)
            ELSE 0
        END AS avg_order_value_with_discount
    FROM order_details od
    JOIN products p ON od.product_id = p.product_id
    JOIN orders o ON od.order_id = o.order_id
    WHERE o.order_status = 'Delivered'
    GROUP BY discount_level
    ORDER BY total_revenue DESC;
END //
DELIMITER ;

-- Procedure 9: Sales Representative Performance Report
DELIMITER //
CREATE PROCEDURE GetSalesRepPerformance(IN start_date DATE, IN end_date DATE)
BEGIN
    SELECT 
        sr.rep_id,
        sr.rep_name,
        r.region_name,
        COUNT(DISTINCT o.order_id) AS orders_handled,
        COUNT(DISTINCT o.customer_id) AS unique_customers,
        SUM(line_total) AS total_sales,
        AVG(line_total) AS avg_order_value,
        SUM(od.quantity) AS total_units_sold,
        SUM(od.discount * od.quantity * od.unit_price) AS total_discount_given,
        sr.base_salary,
        sr.commission_rate,
        sr.base_salary + (SUM(line_total) * sr.commission_rate) AS total_compensation,
        (SUM(line_total) * sr.commission_rate) AS commission_earned,
        CASE 
            WHEN COUNT(DISTINCT o.order_id) > 0 
            THEN SUM(line_total) / COUNT(DISTINCT o.order_id)
            ELSE 0
        END AS revenue_per_order,
        CASE 
            WHEN COUNT(DISTINCT o.customer_id) > 0 
            THEN SUM(line_total) / COUNT(DISTINCT o.customer_id)
            ELSE 0
        END AS revenue_per_customer
    FROM sales_reps sr
    LEFT JOIN orders o ON sr.rep_id = o.sales_rep_id
    LEFT JOIN order_details od ON o.order_id = od.order_id
    LEFT JOIN regions r ON sr.region_id = r.region_id
    WHERE (o.order_date BETWEEN start_date AND end_date OR o.order_id IS NULL) 
          AND (o.order_status = 'Delivered' OR o.order_id IS NULL)
    GROUP BY sr.rep_id, sr.rep_name, r.region_name, sr.base_salary, sr.commission_rate
    ORDER BY total_sales DESC;
END //
DELIMITER ;

-- Procedure 10: Product Category Trends
DELIMITER //
CREATE PROCEDURE GetCategoryTrends(IN months_back INT)
BEGIN
    SELECT 
        cat.category_name,
        DATE_FORMAT(o.order_date, '%Y-%m') AS month,
        SUM(line_total) AS monthly_revenue,
        COUNT(DISTINCT od.order_id) AS monthly_orders,
        SUM(od.quantity) AS monthly_quantity,
        AVG(line_total) AS avg_order_value,
        LAG(SUM(line_total), 1) OVER (PARTITION BY cat.category_name ORDER BY DATE_FORMAT(o.order_date, '%Y-%m')) AS previous_month_revenue,
        CASE 
            WHEN LAG(SUM(line_total), 1) OVER (PARTITION BY cat.category_name ORDER BY DATE_FORMAT(o.order_date, '%Y-%m')) > 0
            THEN ((SUM(line_total) - LAG(SUM(line_total), 1) OVER (PARTITION BY cat.category_name ORDER BY DATE_FORMAT(o.order_date, '%Y-%m'))) / 
                  LAG(SUM(line_total), 1) OVER (PARTITION BY cat.category_name ORDER BY DATE_FORMAT(o.order_date, '%Y-%m'))) * 100
            ELSE NULL
        END AS month_over_month_growth
    FROM categories cat
    LEFT JOIN products p ON cat.category_id = p.category_id
    LEFT JOIN order_details od ON p.product_id = od.product_id
    LEFT JOIN orders o ON od.order_id = o.order_id
    WHERE o.order_date >= DATE_SUB(CURRENT_DATE, INTERVAL months_back MONTH) 
          AND o.order_status = 'Delivered'
    GROUP BY cat.category_name, DATE_FORMAT(o.order_date, '%Y-%m')
    ORDER BY cat.category_name, month;
END //
DELIMITER ;

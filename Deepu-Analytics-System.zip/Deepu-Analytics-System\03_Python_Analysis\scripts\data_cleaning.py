#!/usr/bin/env python3
"""
Data Cleaning Script for Business Analytics System
Handles data cleaning, validation, and preprocessing tasks
"""

import pandas as pd
import numpy as np
import os
import logging
from datetime import datetime, timedelta
import warnings

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('data_cleaning.log'),
        logging.StreamHandler()
    ]
)

class DataCleaner:
    """Comprehensive data cleaning class for business analytics"""
    
    def __init__(self, data_dir='../data'):
        self.data_dir = data_dir
        self.raw_dir = os.path.join(data_dir, 'raw')
        self.cleaned_dir = os.path.join(data_dir, 'cleaned')
        self.processed_dir = os.path.join(data_dir, 'processed')
        
        # Ensure directories exist
        os.makedirs(self.raw_dir, exist_ok=True)
        os.makedirs(self.cleaned_dir, exist_ok=True)
        os.makedirs(self.processed_dir, exist_ok=True)
        
        logging.info("DataCleaner initialized")
    
    def load_sales_data(self, filename='sales_data.csv'):
        """Load and clean sales data"""
        try:
            file_path = os.path.join(self.raw_dir, filename)
            df = pd.read_csv(file_path)
            
            logging.info(f"Loaded sales data: {df.shape}")
            
            # Data cleaning steps
            original_shape = df.shape
            
            # 1. Handle missing values
            df['Discount'].fillna(0, inplace=True)
            df['SalesRep'].fillna('Unassigned', inplace=True)
            
            # 2. Convert data types
            df['OrderDate'] = pd.to_datetime(df['OrderDate'])
            df['Quantity'] = pd.to_numeric(df['Quantity'], errors='coerce')
            df['UnitPrice'] = pd.to_numeric(df['UnitPrice'], errors='coerce')
            df['Discount'] = pd.to_numeric(df['Discount'], errors='coerce')
            
            # 3. Calculate derived columns
            df['TotalAmount'] = df['Quantity'] * df['UnitPrice'] * (1 - df['Discount'])
            df['Profit'] = df['TotalAmount'] * 0.3  # Assuming 30% profit margin
            
            # 4. Add time-based columns
            df['Year'] = df['OrderDate'].dt.year
            df['Month'] = df['OrderDate'].dt.month
            df['Quarter'] = df['OrderDate'].dt.quarter
            df['DayOfWeek'] = df['OrderDate'].dt.day_name()
            
            # 5. Remove duplicates
            df.drop_duplicates(subset=['OrderID'], keep='first', inplace=True)
            
            # 6. Handle outliers in quantity and price
            df = self._handle_outliers(df, 'Quantity')
            df = self._handle_outliers(df, 'UnitPrice')
            
            # 7. Validate data integrity
            df = self._validate_sales_data(df)
            
            logging.info(f"Cleaned sales data: {df.shape} (removed {original_shape[0] - df.shape[0]} rows)")
            
            return df
            
        except Exception as e:
            logging.error(f"Error loading sales data: {e}")
            return None
    
    def load_customer_data(self, filename='customers.csv'):
        """Load and clean customer data"""
        try:
            file_path = os.path.join(self.raw_dir, filename)
            df = pd.read_csv(file_path)
            
            logging.info(f"Loaded customer data: {df.shape}")
            
            # Data cleaning steps
            original_shape = df.shape
            
            # 1. Handle missing values
            df['Phone'].fillna('N/A', inplace=True)
            df['CreditLimit'].fillna(0, inplace=True)
            
            # 2. Convert data types
            df['JoinDate'] = pd.to_datetime(df['JoinDate'])
            df['CreditLimit'] = pd.to_numeric(df['CreditLimit'], errors='coerce')
            
            # 3. Standardize text fields
            df['CompanyName'] = df['CompanyName'].str.strip().str.title()
            df['ContactName'] = df['ContactName'].str.strip().str.title()
            df['City'] = df['City'].str.strip().str.title()
            df['State'] = df['State'].str.strip().str.upper()
            
            # 4. Add derived columns
            df['CustomerAge'] = (datetime.now() - df['JoinDate']).dt.days
            df['CustomerAgeYears'] = df['CustomerAge'] / 365.25
            
            # 5. Remove duplicates
            df.drop_duplicates(subset=['CustomerID'], keep='first', inplace=True)
            
            # 6. Validate email format
            df = self._validate_emails(df)
            
            logging.info(f"Cleaned customer data: {df.shape} (removed {original_shape[0] - df.shape[0]} rows)")
            
            return df
            
        except Exception as e:
            logging.error(f"Error loading customer data: {e}")
            return None
    
    def load_product_data(self, filename='products.csv'):
        """Load and clean product data"""
        try:
            file_path = os.path.join(self.raw_dir, filename)
            df = pd.read_csv(file_path)
            
            logging.info(f"Loaded product data: {df.shape}")
            
            # Data cleaning steps
            original_shape = df.shape
            
            # 1. Handle missing values
            df['Supplier'].fillna('Unknown', inplace=True)
            df['Weight'].fillna(0, inplace=True)
            
            # 2. Convert data types
            df['UnitCost'] = pd.to_numeric(df['UnitCost'], errors='coerce')
            df['UnitPrice'] = pd.to_numeric(df['UnitPrice'], errors='coerce')
            df['ReorderLevel'] = pd.to_numeric(df['ReorderLevel'], errors='coerce')
            df['Weight'] = pd.to_numeric(df['Weight'], errors='coerce')
            df['LaunchDate'] = pd.to_datetime(df['LaunchDate'])
            
            # 3. Calculate derived columns
            df['ProfitMargin'] = ((df['UnitPrice'] - df['UnitCost']) / df['UnitPrice']) * 100
            df['ProfitAmount'] = df['UnitPrice'] - df['UnitCost']
            df['ProductAge'] = (datetime.now() - df['LaunchDate']).dt.days
            
            # 4. Categorize products by price
            df['PriceCategory'] = pd.cut(df['UnitPrice'], 
                                        bins=[0, 50, 200, 500, float('inf')],
                                        labels=['Budget', 'Mid-Range', 'Premium', 'Luxury'])
            
            # 5. Remove duplicates
            df.drop_duplicates(subset=['ProductID'], keep='first', inplace=True)
            
            # 6. Validate business rules
            df = self._validate_product_data(df)
            
            logging.info(f"Cleaned product data: {df.shape} (removed {original_shape[0] - df.shape[0]} rows)")
            
            return df
            
        except Exception as e:
            logging.error(f"Error loading product data: {e}")
            return None
    
    def _handle_outliers(self, df, column, method='iqr'):
        """Handle outliers using IQR method"""
        try:
            if method == 'iqr':
                Q1 = df[column].quantile(0.25)
                Q3 = df[column].quantile(0.75)
                IQR = Q3 - Q1
                
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                # Cap outliers instead of removing them
                df[column] = np.where(df[column] < lower_bound, lower_bound, df[column])
                df[column] = np.where(df[column] > upper_bound, upper_bound, df[column])
                
                logging.info(f"Handled outliers in {column} using IQR method")
            
            return df
            
        except Exception as e:
            logging.error(f"Error handling outliers in {column}: {e}")
            return df
    
    def _validate_sales_data(self, df):
        """Validate sales data integrity"""
        try:
            # Remove rows with negative quantities or prices
            df = df[df['Quantity'] > 0]
            df = df[df['UnitPrice'] > 0]
            
            # Validate discount range
            df = df[(df['Discount'] >= 0) & (df['Discount'] <= 1)]
            
            # Validate date ranges (no future dates)
            df = df[df['OrderDate'] <= datetime.now()]
            
            logging.info("Sales data validation completed")
            return df
            
        except Exception as e:
            logging.error(f"Error validating sales data: {e}")
            return df
    
    def _validate_emails(self, df):
        """Validate email format"""
        try:
            import re
            
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            
            # Keep only valid emails
            df = df[df['Email'].str.match(email_pattern, na=False)]
            
            logging.info("Email validation completed")
            return df
            
        except Exception as e:
            logging.error(f"Error validating emails: {e}")
            return df
    
    def _validate_product_data(self, df):
        """Validate product data"""
        try:
            # Remove products with negative costs or prices
            df = df[df['UnitCost'] >= 0]
            df = df[df['UnitPrice'] > 0]
            
            # Ensure price is greater than cost
            df = df[df['UnitPrice'] >= df['UnitCost']]
            
            # Remove products with negative reorder levels
            df = df[df['ReorderLevel'] >= 0]
            
            logging.info("Product data validation completed")
            return df
            
        except Exception as e:
            logging.error(f"Error validating product data: {e}")
            return df
    
    def create_master_dataset(self, sales_df, customers_df, products_df):
        """Create a master dataset by merging all data"""
        try:
            # Merge sales with customers
            master_df = sales_df.merge(customers_df, 
                                      left_on='CustomerID', 
                                      right_on='CustomerID', 
                                      how='left')
            
            # Merge with products
            master_df = master_df.merge(products_df, 
                                       on='ProductID', 
                                       how='left')
            
            # Add additional calculated columns
            master_df['CustomerLifetimeValue'] = master_df.groupby('CustomerID')['TotalAmount'].transform('sum')
            master_df['ProductRevenueContribution'] = master_df.groupby('ProductID')['TotalAmount'].transform('sum')
            
            # Add customer segmentation
            master_df['CustomerSegment'] = pd.cut(master_df['CustomerLifetimeValue'],
                                                bins=[0, 1000, 5000, 20000, float('inf')],
                                                labels=['Bronze', 'Silver', 'Gold', 'Platinum'])
            
            logging.info(f"Created master dataset: {master_df.shape}")
            
            return master_df
            
        except Exception as e:
            logging.error(f"Error creating master dataset: {e}")
            return None
    
    def save_cleaned_data(self, df, filename, data_type='cleaned'):
        """Save cleaned data to appropriate directory"""
        try:
            if data_type == 'cleaned':
                output_dir = self.cleaned_dir
            elif data_type == 'processed':
                output_dir = self.processed_dir
            else:
                output_dir = self.data_dir
            
            output_path = os.path.join(output_dir, filename)
            
            if filename.endswith('.csv'):
                df.to_csv(output_path, index=False)
            elif filename.endswith('.xlsx'):
                df.to_excel(output_path, index=False, engine='openpyxl')
            else:
                df.to_csv(output_path + '.csv', index=False)
            
            logging.info(f"Saved {filename} to {output_path}")
            
        except Exception as e:
            logging.error(f"Error saving {filename}: {e}")
    
    def generate_data_quality_report(self, sales_df, customers_df, products_df):
        """Generate comprehensive data quality report"""
        try:
            report = {
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'datasets': {}
            }
            
            # Sales data quality
            report['datasets']['sales'] = {
                'total_records': len(sales_df),
                'missing_values': sales_df.isnull().sum().to_dict(),
                'data_types': sales_df.dtypes.to_dict(),
                'duplicate_orders': sales_df['OrderID'].duplicated().sum(),
                'date_range': {
                    'start': sales_df['OrderDate'].min().strftime('%Y-%m-%d'),
                    'end': sales_df['OrderDate'].max().strftime('%Y-%m-%d')
                },
                'total_revenue': float(sales_df['TotalAmount'].sum()),
                'avg_order_value': float(sales_df['TotalAmount'].mean())
            }
            
            # Customer data quality
            report['datasets']['customers'] = {
                'total_records': len(customers_df),
                'missing_values': customers_df.isnull().sum().to_dict(),
                'data_types': customers_df.dtypes.to_dict(),
                'customer_types': customers_df['CustomerType'].value_counts().to_dict(),
                'avg_customer_age': float(customers_df['CustomerAgeYears'].mean())
            }
            
            # Product data quality
            report['datasets']['products'] = {
                'total_records': len(products_df),
                'missing_values': products_df.isnull().sum().to_dict(),
                'data_types': products_df.dtypes.to_dict(),
                'categories': products_df['Category'].value_counts().to_dict(),
                'avg_profit_margin': float(products_df['ProfitMargin'].mean())
            }
            
            # Save report
            import json
            report_path = os.path.join(self.processed_dir, 'data_quality_report.json')
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            logging.info("Data quality report generated")
            return report
            
        except Exception as e:
            logging.error(f"Error generating data quality report: {e}")
            return None

def main():
    """Main execution function"""
    print("Starting data cleaning process...")
    
    # Initialize data cleaner
    cleaner = DataCleaner()
    
    # Load and clean datasets
    sales_df = cleaner.load_sales_data()
    customers_df = cleaner.load_customer_data()
    products_df = cleaner.load_product_data()
    
    if all(df is not None for df in [sales_df, customers_df, products_df]):
        # Save cleaned datasets
        cleaner.save_cleaned_data(sales_df, 'sales_cleaned.csv', 'cleaned')
        cleaner.save_cleaned_data(customers_df, 'customers_cleaned.csv', 'cleaned')
        cleaner.save_cleaned_data(products_df, 'products_cleaned.csv', 'cleaned')
        
        # Create master dataset
        master_df = cleaner.create_master_dataset(sales_df, customers_df, products_df)
        if master_df is not None:
            cleaner.save_cleaned_data(master_df, 'master_dataset.csv', 'processed')
        
        # Generate data quality report
        quality_report = cleaner.generate_data_quality_report(sales_df, customers_df, products_df)
        
        print("Data cleaning completed successfully!")
        print(f"Cleaned datasets saved to: {cleaner.cleaned_dir}")
        print(f"Processed datasets saved to: {cleaner.processed_dir}")
        
    else:
        print("Data cleaning failed. Check logs for details.")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Business Insights Generator for Capstone Project
Advanced analytics and insights generation for decision support
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

class BusinessInsightsGenerator:
    """Advanced business insights generator"""
    
    def __init__(self, data_path='../data/processed'):
        self.data_path = data_path
        self.master_df = None
        self.insights = {}
        
        # Load data
        self._load_data()
    
    def _load_data(self):
        """Load processed data"""
        try:
            self.master_df = pd.read_csv(f'{self.data_path}/master_dataset.csv')
            self.master_df['OrderDate'] = pd.to_datetime(self.master_df['OrderDate'])
            print(f"Loaded master dataset: {self.master_df.shape}")
        except Exception as e:
            print(f"Error loading data: {e}")
    
    def generate_customer_segmentation(self):
        """Generate advanced customer segmentation"""
        try:
            # Prepare customer features
            customer_features = self.master_df.groupby('CustomerID').agg({
                'TotalAmount': ['sum', 'mean', 'count'],
                'OrderDate': ['min', 'max'],
                'CustomerAge': 'first',
                'CustomerType': 'first'
            }).reset_index()
            
            # Flatten column names
            customer_features.columns = ['CustomerID', 'LifetimeValue', 'AvgOrderValue', 
                                       'OrderCount', 'FirstOrder', 'LastOrder', 
                                       'CustomerAge', 'CustomerType']
            
            # Calculate additional features
            customer_features['Recency'] = (pd.Timestamp.now() - customer_features['LastOrder']).dt.days
            customer_features['Tenure'] = (customer_features['LastOrder'] - customer_features['FirstOrder']).dt.days
            customer_features['OrderFrequency'] = customer_features['Tenure'] / customer_features['OrderCount']
            
            # Select features for clustering
            features_for_clustering = ['LifetimeValue', 'AvgOrderValue', 'OrderCount', 
                                    'Recency', 'Tenure', 'OrderFrequency']
            
            X = customer_features[features_for_clustering].fillna(0)
            
            # Standardize features
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            # Determine optimal number of clusters
            optimal_k = self._find_optimal_clusters(X_scaled)
            
            # Perform clustering
            kmeans = KMeans(n_clusters=optimal_k, random_state=42)
            customer_features['Cluster'] = kmeans.fit_predict(X_scaled)
            
            # Analyze clusters
            cluster_analysis = self._analyze_clusters(customer_features)
            
            self.insights['customer_segmentation'] = {
                'optimal_clusters': optimal_k,
                'cluster_analysis': cluster_analysis,
                'silhouette_score': silhouette_score(X_scaled, kmeans.labels_)
            }
            
            return cluster_analysis
            
        except Exception as e:
            print(f"Error in customer segmentation: {e}")
            return None
    
    def _find_optimal_clusters(self, X, max_k=10):
        """Find optimal number of clusters using elbow method"""
        inertias = []
        silhouette_scores = []
        
        for k in range(2, min(max_k + 1, len(X))):
            kmeans = KMeans(n_clusters=k, random_state=42)
            labels = kmeans.fit_predict(X)
            inertias.append(kmeans.inertia_)
            silhouette_scores.append(silhouette_score(X, labels))
        
        # Find elbow point (simplified)
        optimal_k = 3  # Default to 3 for business segments
        
        return optimal_k
    
    def _analyze_clusters(self, customer_features):
        """Analyze customer clusters"""
        cluster_analysis = {}
        
        for cluster_id in customer_features['Cluster'].unique():
            cluster_data = customer_features[customer_features['Cluster'] == cluster_id]
            
            cluster_analysis[f'Cluster_{cluster_id}'] = {
                'size': len(cluster_data),
                'avg_lifetime_value': cluster_data['LifetimeValue'].mean(),
                'avg_order_value': cluster_data['AvgOrderValue'].mean(),
                'avg_order_count': cluster_data['OrderCount'].mean(),
                'avg_recency': cluster_data['Recency'].mean(),
                'dominant_customer_type': cluster_data['CustomerType'].mode().iloc[0] if not cluster_data['CustomerType'].mode().empty else 'Unknown',
                'characteristics': self._describe_cluster_characteristics(cluster_data)
            }
        
        return cluster_analysis
    
    def _describe_cluster_characteristics(self, cluster_data):
        """Describe cluster characteristics"""
        characteristics = []
        
        if cluster_data['LifetimeValue'].mean() > 10000:
            characteristics.append("High Value")
        elif cluster_data['LifetimeValue'].mean() < 1000:
            characteristics.append("Low Value")
        else:
            characteristics.append("Medium Value")
        
        if cluster_data['OrderCount'].mean() > 10:
            characteristics.append("Frequent Buyers")
        elif cluster_data['OrderCount'].mean() < 3:
            characteristics.append("Infrequent Buyers")
        
        if cluster_data['Recency'].mean() < 30:
            characteristics.append("Recent Active")
        elif cluster_data['Recency'].mean() > 180:
            characteristics.append("At Risk")
        
        return characteristics
    
    def generate_product_affinity_analysis(self):
        """Generate product affinity analysis"""
        try:
            # Create product co-occurrence matrix
            product_orders = self.master_df.groupby('OrderID')['ProductID'].apply(list).reset_index()
            
            # Calculate product pairs
            product_pairs = {}
            for products in product_orders['ProductID']:
                for i in range(len(products)):
                    for j in range(i + 1, len(products)):
                        pair = tuple(sorted([products[i], products[j]]))
                        product_pairs[pair] = product_pairs.get(pair, 0) + 1
            
            # Convert to DataFrame
            affinity_df = pd.DataFrame([
                {'Product1': pair[0], 'Product2': pair[1], 'CoOccurrences': count}
                for pair, count in product_pairs.items()
            ]).sort_values('CoOccurrences', ascending=False)
            
            # Calculate affinity scores
            total_orders = len(product_orders)
            affinity_df['AffinityScore'] = affinity_df['CoOccurrences'] / total_orders
            
            # Get top product pairs
            top_affinities = affinity_df.head(20)
            
            self.insights['product_affinity'] = {
                'top_affinities': top_affinities.to_dict('records'),
                'total_unique_pairs': len(affinity_df),
                'avg_co_occurrences': affinity_df['CoOccurrences'].mean()
            }
            
            return top_affinities
            
        except Exception as e:
            print(f"Error in product affinity analysis: {e}")
            return None
    
    def generate_revenue_forecast(self, periods=90):
        """Generate revenue forecast using simple time series analysis"""
        try:
            # Prepare time series data
            daily_revenue = self.master_df.groupby('OrderDate')['TotalAmount'].sum().reset_index()
            daily_revenue = daily_revenue.sort_values('OrderDate')
            
            # Calculate moving averages
            daily_revenue['7_day_MA'] = daily_revenue['TotalAmount'].rolling(window=7).mean()
            daily_revenue['30_day_MA'] = daily_revenue['TotalAmount'].rolling(window=30).mean()
            
            # Simple linear trend forecast
            from sklearn.linear_model import LinearRegression
            
            # Prepare data for forecasting
            daily_revenue['Days'] = (daily_revenue['OrderDate'] - daily_revenue['OrderDate'].min()).dt.days
            
            # Fit linear regression on recent data (last 60 days)
            recent_data = daily_revenue.tail(60).dropna()
            X = recent_data[['Days']]
            y = recent_data['TotalAmount']
            
            model = LinearRegression()
            model.fit(X, y)
            
            # Generate forecast
            last_day = daily_revenue['Days'].max()
            forecast_days = list(range(last_day + 1, last_day + periods + 1))
            forecast_dates = [daily_revenue['OrderDate'].min() + pd.Timedelta(days=d) for d in forecast_days]
            
            forecast_X = [[d] for d in forecast_days]
            forecast_values = model.predict(forecast_X)
            
            # Create forecast DataFrame
            forecast_df = pd.DataFrame({
                'Date': forecast_dates,
                'PredictedRevenue': forecast_values
            })
            
            # Calculate confidence intervals (simplified)
            forecast_std = recent_data['TotalAmount'].std()
            forecast_df['LowerBound'] = forecast_df['PredictedRevenue'] - 1.96 * forecast_std
            forecast_df['UpperBound'] = forecast_df['PredictedRevenue'] + 1.96 * forecast_std
            
            self.insights['revenue_forecast'] = {
                'forecast_period_days': periods,
                'total_predicted_revenue': forecast_df['PredictedRevenue'].sum(),
                'avg_daily_revenue': forecast_df['PredictedRevenue'].mean(),
                'trend_slope': model.coef_[0],
                'model_score': model.score(X, y)
            }
            
            return forecast_df
            
        except Exception as e:
            print(f"Error in revenue forecast: {e}")
            return None
    
    def generate_market_basket_analysis(self):
        """Generate market basket analysis insights"""
        try:
            # Create basket data
            baskets = self.master_df.groupby('OrderID')['ProductName'].apply(list).tolist()
            
            # Calculate product frequencies
            from collections import Counter
            all_products = [product for basket in baskets for product in basket]
            product_frequencies = Counter(all_products)
            
            # Calculate basket statistics
            basket_sizes = [len(basket) for basket in baskets]
            
            # Find common product combinations
            from itertools import combinations
            pair_frequencies = Counter()
            
            for basket in baskets:
                for pair in combinations(basket, 2):
                    pair_frequencies[pair] += 1
            
            # Get top combinations
            top_combinations = pair_frequencies.most_common(10)
            
            self.insights['market_basket'] = {
                'total_baskets': len(baskets),
                'avg_basket_size': np.mean(basket_sizes),
                'most_common_products': product_frequencies.most_common(10),
                'top_combinations': top_combinations,
                'unique_products': len(product_frequencies)
            }
            
            return {
                'avg_basket_size': np.mean(basket_sizes),
                'top_combinations': top_combinations,
                'product_frequencies': product_frequencies.most_common(10)
            }
            
        except Exception as e:
            print(f"Error in market basket analysis: {e}")
            return None
    
    def generate_churn_prediction_insights(self):
        """Generate customer churn prediction insights"""
        try:
            # Define churn (customers who haven't purchased in last 90 days)
            current_date = self.master_df['OrderDate'].max()
            churn_threshold = current_date - pd.Timedelta(days=90)
            
            # Calculate customer activity
            customer_activity = self.master_df.groupby('CustomerID').agg({
                'OrderDate': 'max',
                'TotalAmount': 'sum',
                'OrderID': 'count'
            }).reset_index()
            
            customer_activity.columns = ['CustomerID', 'LastOrderDate', 'LifetimeValue', 'OrderCount']
            
            # Label churn
            customer_activity['Churned'] = customer_activity['LastOrderDate'] < churn_threshold
            
            # Calculate churn rate
            churn_rate = customer_activity['Churned'].mean()
            
            # Analyze churn by customer type
            customer_info = self.master_df[['CustomerID', 'CustomerType']].drop_duplicates()
            customer_activity = customer_activity.merge(customer_info, on='CustomerID')
            
            churn_by_type = customer_activity.groupby('CustomerType')['Churned'].mean()
            
            # Identify churn risk factors
            churned_customers = customer_activity[customer_activity['Churned']]
            active_customers = customer_activity[~customer_activity['Churned']]
            
            risk_factors = {
                'avg_lifetime_value_churned': churned_customers['LifetimeValue'].mean(),
                'avg_lifetime_value_active': active_customers['LifetimeValue'].mean(),
                'avg_order_count_churned': churned_customers['OrderCount'].mean(),
                'avg_order_count_active': active_customers['OrderCount'].mean()
            }
            
            self.insights['churn_analysis'] = {
                'overall_churn_rate': churn_rate,
                'churn_by_customer_type': churn_by_type.to_dict(),
                'risk_factors': risk_factors,
                'total_churned_customers': len(churned_customers),
                'total_active_customers': len(active_customers)
            }
            
            return {
                'churn_rate': churn_rate,
                'churn_by_type': churn_by_type,
                'risk_factors': risk_factors
            }
            
        except Exception as e:
            print(f"Error in churn prediction: {e}")
            return None
    
    def generate_comprehensive_report(self):
        """Generate comprehensive business insights report"""
        try:
            print("Generating comprehensive business insights...")
            
            # Generate all insights
            customer_segments = self.generate_customer_segmentation()
            product_affinity = self.generate_product_affinity_analysis()
            revenue_forecast = self.generate_revenue_forecast()
            market_basket = self.generate_market_basket_analysis()
            churn_analysis = self.generate_churn_prediction_insights()
            
            # Compile executive summary
            executive_summary = {
                'total_revenue': self.master_df['TotalAmount'].sum(),
                'total_customers': self.master_df['CustomerID'].nunique(),
                'total_orders': len(self.master_df),
                'avg_order_value': self.master_df['TotalAmount'].mean(),
                'key_insights': self._generate_key_insights()
            }
            
            # Create complete report
            report = {
                'report_date': pd.Timestamp.now().isoformat(),
                'executive_summary': executive_summary,
                'insights': self.insights
            }
            
            # Save report
            import json
            report_path = f'{self.data_path}/../reports/business_insights_report.json'
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            print(f"Comprehensive report saved to {report_path}")
            return report
            
        except Exception as e:
            print(f"Error generating comprehensive report: {e}")
            return None
    
    def _generate_key_insights(self):
        """Generate key business insights"""
        insights = []
        
        try:
            # Revenue insights
            monthly_revenue = self.master_df.groupby(['Year', 'Month'])['TotalAmount'].sum()
            if len(monthly_revenue) > 1:
                revenue_growth = (monthly_revenue.iloc[-1] - monthly_revenue.iloc[-2]) / monthly_revenue.iloc[-2] * 100
                if revenue_growth > 10:
                    insights.append(f"Strong revenue growth of {revenue_growth:.1f}% this month")
                elif revenue_growth < -5:
                    insights.append(f"Revenue decline of {abs(revenue_growth):.1f}% this month - requires attention")
            
            # Customer insights
            high_value_customers = self.master_df.groupby('CustomerID')['TotalAmount'].sum()
            top_10_percent_revenue = high_value_customers.quantile(0.9)
            top_customers_revenue_share = high_value_customers[high_value_customers >= top_10_percent_revenue].sum() / high_value_customers.sum() * 100
            
            if top_customers_revenue_share > 60:
                insights.append(f"Top 10% of customers generate {top_customers_revenue_share:.1f}% of revenue - focus on retention")
            
            # Product insights
            category_performance = self.master_df.groupby('Category')['TotalAmount'].sum()
            top_category = category_performance.idxmax()
            top_category_share = category_performance.max() / category_performance.sum() * 100
            
            insights.append(f"{top_category} category dominates with {top_category_share:.1f}% of total revenue")
            
            # Regional insights
            regional_performance = self.master_df.groupby('Region')['TotalAmount'].sum()
            best_region = regional_performance.idxmax()
            worst_region = regional_performance.idxmin()
            
            insights.append(f"Best performing region: {best_region}, Worst performing: {worst_region}")
            
        except Exception as e:
            print(f"Error generating key insights: {e}")
        
        return insights

def main():
    """Main execution function"""
    print("Starting Business Insights Generation...")
    
    # Initialize insights generator
    generator = BusinessInsightsGenerator()
    
    if generator.master_df is not None:
        # Generate comprehensive report
        report = generator.generate_comprehensive_report()
        
        if report:
            print("\nBusiness Insights Generated Successfully!")
            print(f"Report Date: {report['report_date']}")
            print(f"Total Revenue: ${report['executive_summary']['total_revenue']:,.2f}")
            print(f"Total Customers: {report['executive_summary']['total_customers']:,}")
            print(f"Total Orders: {report['executive_summary']['total_orders']:,}")
            
            print("\nKey Insights:")
            for insight in report['executive_summary']['key_insights']:
                print(f"  - {insight}")
        else:
            print("Failed to generate business insights")
    else:
        print("No data available for insights generation")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
End-to-End Data Pipeline for Business Analytics System
Comprehensive pipeline for data ingestion, processing, and analysis
"""

import pandas as pd
import numpy as np
import mysql.connector
from sqlalchemy import create_engine
import logging
import os
import json
from datetime import datetime, timedelta
import schedule
import time
from typing import Dict, List, Any
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('data_pipeline.log'),
        logging.StreamHandler()
    ]
)

class DataPipeline:
    """End-to-end data pipeline for business analytics"""
    
    def __init__(self, config_path='../config/config.yaml'):
        self.config = self._load_config(config_path)
        self.db_connection = None
        self.pipeline_status = {
            'last_run': None,
            'status': 'idle',
            'records_processed': 0,
            'errors': []
        }
        
        logging.info("DataPipeline initialized")
    
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file"""
        try:
            import yaml
            with open(config_path, 'r') as file:
                config = yaml.safe_load(file)
            return config
        except Exception as e:
            logging.error(f"Error loading config: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        """Get default configuration"""
        return {
            'database': {
                'host': 'localhost',
                'port': 3306,
                'database': 'business_analytics',
                'user': 'root',
                'password': 'password'
            },
            'data_paths': {
                'raw': '../data/raw',
                'cleaned': '../data/cleaned',
                'processed': '../data/processed'
            },
            'pipeline': {
                'batch_size': 1000,
                'retry_attempts': 3,
                'schedule_interval': 'hourly'
            }
        }
    
    def establish_database_connection(self):
        """Establish database connection"""
        try:
            db_config = self.config['database']
            connection_string = f"mysql+pymysql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['database']}"
            self.db_connection = create_engine(connection_string)
            logging.info("Database connection established")
            return True
        except Exception as e:
            logging.error(f"Database connection failed: {e}")
            return False
    
    def extract_data(self) -> Dict[str, pd.DataFrame]:
        """Extract data from various sources"""
        try:
            logging.info("Starting data extraction")
            
            data = {}
            
            # 1. Extract from CSV files
            data.update(self._extract_from_csv())
            
            # 2. Extract from database
            if self.db_connection:
                data.update(self._extract_from_database())
            
            # 3. Extract from API (if configured)
            data.update(self._extract_from_api())
            
            logging.info(f"Data extraction completed. Sources: {list(data.keys())}")
            return data
            
        except Exception as e:
            logging.error(f"Error in data extraction: {e}")
            return {}
    
    def _extract_from_csv(self) -> Dict[str, pd.DataFrame]:
        """Extract data from CSV files"""
        data = {}
        csv_files = {
            'sales': '../data/raw/sales_data.csv',
            'customers': '../data/raw/customers.csv',
            'products': '../data/raw/products.csv'
        }
        
        for name, file_path in csv_files.items():
            try:
                if os.path.exists(file_path):
                    df = pd.read_csv(file_path)
                    data[name] = df
                    logging.info(f"Loaded {name} data: {df.shape}")
                else:
                    logging.warning(f"CSV file not found: {file_path}")
            except Exception as e:
                logging.error(f"Error loading {name} from CSV: {e}")
        
        return data
    
    def _extract_from_database(self) -> Dict[str, pd.DataFrame]:
        """Extract data from database"""
        data = {}
        queries = {
            'orders': "SELECT * FROM orders WHERE order_status = 'Delivered'",
            'order_details': "SELECT * FROM order_details",
            'regions': "SELECT * FROM regions",
            'sales_reps': "SELECT * FROM sales_reps"
        }
        
        for name, query in queries.items():
            try:
                df = pd.read_sql(query, self.db_connection)
                data[name] = df
                logging.info(f"Loaded {name} data from database: {df.shape}")
            except Exception as e:
                logging.error(f"Error loading {name} from database: {e}")
        
        return data
    
    def _extract_from_api(self) -> Dict[str, pd.DataFrame]:
        """Extract data from external APIs"""
        data = {}
        
        # Example: Extract market data from API
        try:
            # This is a placeholder for API integration
            # In real implementation, you would call actual APIs
            logging.info("API extraction not configured, skipping")
        except Exception as e:
            logging.error(f"Error in API extraction: {e}")
        
        return data
    
    def transform_data(self, raw_data: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """Transform and clean data"""
        try:
            logging.info("Starting data transformation")
            
            transformed_data = {}
            
            # 1. Clean sales data
            if 'sales' in raw_data:
                transformed_data['sales_cleaned'] = self._transform_sales_data(raw_data['sales'])
            
            # 2. Clean customer data
            if 'customers' in raw_data:
                transformed_data['customers_cleaned'] = self._transform_customer_data(raw_data['customers'])
            
            # 3. Clean product data
            if 'products' in raw_data:
                transformed_data['products_cleaned'] = self._transform_product_data(raw_data['products'])
            
            # 4. Create master dataset
            if all(key in transformed_data for key in ['sales_cleaned', 'customers_cleaned', 'products_cleaned']):
                transformed_data['master_dataset'] = self._create_master_dataset(transformed_data)
            
            # 5. Create analytical datasets
            transformed_data.update(self._create_analytical_datasets(transformed_data))
            
            logging.info("Data transformation completed")
            return transformed_data
            
        except Exception as e:
            logging.error(f"Error in data transformation: {e}")
            return {}
    
    def _transform_sales_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform sales data"""
        try:
            # Make a copy to avoid modifying original
            df = df.copy()
            
            # Handle missing values
            df['Discount'].fillna(0, inplace=True)
            df['SalesRep'].fillna('Unassigned', inplace=True)
            
            # Convert data types
            df['OrderDate'] = pd.to_datetime(df['OrderDate'])
            df['Quantity'] = pd.to_numeric(df['Quantity'], errors='coerce')
            df['UnitPrice'] = pd.to_numeric(df['UnitPrice'], errors='coerce')
            df['Discount'] = pd.to_numeric(df['Discount'], errors='coerce')
            
            # Calculate derived columns
            df['TotalAmount'] = df['Quantity'] * df['UnitPrice'] * (1 - df['Discount'])
            df['Profit'] = df['TotalAmount'] * 0.3  # Assuming 30% profit margin
            
            # Add time-based columns
            df['Year'] = df['OrderDate'].dt.year
            df['Month'] = df['OrderDate'].dt.month
            df['Quarter'] = df['OrderDate'].dt.quarter
            df['DayOfWeek'] = df['OrderDate'].dt.day_name()
            
            # Remove duplicates
            df.drop_duplicates(subset=['OrderID'], keep='first', inplace=True)
            
            # Validate data
            df = df[df['Quantity'] > 0]
            df = df[df['UnitPrice'] > 0]
            df = df[(df['Discount'] >= 0) & (df['Discount'] <= 1)]
            
            logging.info(f"Transformed sales data: {df.shape}")
            return df
            
        except Exception as e:
            logging.error(f"Error transforming sales data: {e}")
            return pd.DataFrame()
    
    def _transform_customer_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform customer data"""
        try:
            df = df.copy()
            
            # Handle missing values
            df['Phone'].fillna('N/A', inplace=True)
            df['CreditLimit'].fillna(0, inplace=True)
            
            # Convert data types
            df['JoinDate'] = pd.to_datetime(df['JoinDate'])
            df['CreditLimit'] = pd.to_numeric(df['CreditLimit'], errors='coerce')
            
            # Standardize text fields
            df['CompanyName'] = df['CompanyName'].str.strip().str.title()
            df['ContactName'] = df['ContactName'].str.strip().str.title()
            df['City'] = df['City'].str.strip().str.title()
            df['State'] = df['State'].str.strip().str.upper()
            
            # Add derived columns
            df['CustomerAge'] = (datetime.now() - df['JoinDate']).dt.days
            df['CustomerAgeYears'] = df['CustomerAge'] / 365.25
            
            # Remove duplicates
            df.drop_duplicates(subset=['CustomerID'], keep='first', inplace=True)
            
            logging.info(f"Transformed customer data: {df.shape}")
            return df
            
        except Exception as e:
            logging.error(f"Error transforming customer data: {e}")
            return pd.DataFrame()
    
    def _transform_product_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform product data"""
        try:
            df = df.copy()
            
            # Handle missing values
            df['Supplier'].fillna('Unknown', inplace=True)
            df['Weight'].fillna(0, inplace=True)
            
            # Convert data types
            df['UnitCost'] = pd.to_numeric(df['UnitCost'], errors='coerce')
            df['UnitPrice'] = pd.to_numeric(df['UnitPrice'], errors='coerce')
            df['ReorderLevel'] = pd.to_numeric(df['ReorderLevel'], errors='coerce')
            df['Weight'] = pd.to_numeric(df['Weight'], errors='coerce')
            df['LaunchDate'] = pd.to_datetime(df['LaunchDate'])
            
            # Calculate derived columns
            df['ProfitMargin'] = ((df['UnitPrice'] - df['UnitCost']) / df['UnitPrice']) * 100
            df['ProfitAmount'] = df['UnitPrice'] - df['UnitCost']
            df['ProductAge'] = (datetime.now() - df['LaunchDate']).dt.days
            
            # Categorize products by price
            df['PriceCategory'] = pd.cut(df['UnitPrice'], 
                                        bins=[0, 50, 200, 500, float('inf')],
                                        labels=['Budget', 'Mid-Range', 'Premium', 'Luxury'])
            
            # Remove duplicates
            df.drop_duplicates(subset=['ProductID'], keep='first', inplace=True)
            
            # Validate business rules
            df = df[df['UnitPrice'] >= df['UnitCost']]
            df = df[df['UnitPrice'] > 0]
            df = df[df['UnitCost'] >= 0]
            
            logging.info(f"Transformed product data: {df.shape}")
            return df
            
        except Exception as e:
            logging.error(f"Error transforming product data: {e}")
            return pd.DataFrame()
    
    def _create_master_dataset(self, transformed_data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """Create master dataset by merging all data"""
        try:
            # Start with sales data
            master_df = transformed_data['sales_cleaned'].copy()
            
            # Merge with customers
            master_df = master_df.merge(
                transformed_data['customers_cleaned'], 
                on='CustomerID', 
                how='left'
            )
            
            # Merge with products
            master_df = master_df.merge(
                transformed_data['products_cleaned'], 
                on='ProductID', 
                how='left'
            )
            
            # Add calculated columns
            master_df['CustomerLifetimeValue'] = master_df.groupby('CustomerID')['TotalAmount'].transform('sum')
            master_df['ProductRevenueContribution'] = master_df.groupby('ProductID')['TotalAmount'].transform('sum')
            
            # Add customer segmentation
            master_df['CustomerSegment'] = pd.cut(master_df['CustomerLifetimeValue'],
                                                bins=[0, 1000, 5000, 20000, float('inf')],
                                                labels=['Bronze', 'Silver', 'Gold', 'Platinum'])
            
            logging.info(f"Created master dataset: {master_df.shape}")
            return master_df
            
        except Exception as e:
            logging.error(f"Error creating master dataset: {e}")
            return pd.DataFrame()
    
    def _create_analytical_datasets(self, transformed_data: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """Create specialized analytical datasets"""
        datasets = {}
        
        try:
            # 1. Monthly performance dataset
            if 'sales_cleaned' in transformed_data:
                monthly_data = transformed_data['sales_cleaned'].groupby(['Year', 'Month']).agg({
                    'TotalAmount': 'sum',
                    'Quantity': 'sum',
                    'OrderID': 'count',
                    'Profit': 'sum'
                }).reset_index()
                monthly_data['Period'] = monthly_data['Year'].astype(str) + '-' + monthly_data['Month'].astype(str).str.zfill(2)
                datasets['monthly_performance'] = monthly_data
            
            # 2. Customer analytics dataset
            if 'master_dataset' in transformed_data:
                customer_analytics = transformed_data['master_dataset'].groupby('CustomerID').agg({
                    'TotalAmount': 'sum',
                    'OrderID': 'count',
                    'OrderDate': ['min', 'max'],
                    'CustomerType': 'first',
                    'CustomerSegment': 'first'
                }).reset_index()
                customer_analytics.columns = ['CustomerID', 'LifetimeValue', 'OrderCount', 
                                           'FirstOrder', 'LastOrder', 'CustomerType', 'CustomerSegment']
                datasets['customer_analytics'] = customer_analytics
            
            # 3. Product performance dataset
            if 'sales_cleaned' in transformed_data and 'products_cleaned' in transformed_data:
                product_performance = transformed_data['sales_cleaned'].groupby('ProductID').agg({
                    'TotalAmount': 'sum',
                    'Quantity': 'sum',
                    'OrderID': 'count'
                }).reset_index()
                product_performance = product_performance.merge(
                    transformed_data['products_cleaned'][['ProductID', 'ProductName', 'Category', 'ProfitMargin']],
                    on='ProductID'
                )
                datasets['product_performance'] = product_performance
            
            # 4. Regional performance dataset
            if 'sales_cleaned' in transformed_data:
                regional_performance = transformed_data['sales_cleaned'].groupby('Region').agg({
                    'TotalAmount': 'sum',
                    'Quantity': 'sum',
                    'OrderID': 'count',
                    'CustomerID': 'nunique'
                }).reset_index()
                regional_performance.columns = ['Region', 'TotalRevenue', 'TotalQuantity', 'OrderCount', 'UniqueCustomers']
                datasets['regional_performance'] = regional_performance
            
            logging.info(f"Created {len(datasets)} analytical datasets")
            return datasets
            
        except Exception as e:
            logging.error(f"Error creating analytical datasets: {e}")
            return {}
    
    def load_data(self, transformed_data: Dict[str, pd.DataFrame]):
        """Load transformed data to various destinations"""
        try:
            logging.info("Starting data loading")
            
            # 1. Save to CSV files
            self._save_to_csv(transformed_data)
            
            # 2. Load to database
            if self.db_connection:
                self._load_to_database(transformed_data)
            
            # 3. Generate reports
            self._generate_reports(transformed_data)
            
            logging.info("Data loading completed")
            
        except Exception as e:
            logging.error(f"Error in data loading: {e}")
    
    def _save_to_csv(self, data: Dict[str, pd.DataFrame]):
        """Save data to CSV files"""
        try:
            base_path = self.config['data_paths']['processed']
            os.makedirs(base_path, exist_ok=True)
            
            for name, df in data.items():
                if not df.empty:
                    file_path = os.path.join(base_path, f'{name}.csv')
                    df.to_csv(file_path, index=False)
                    logging.info(f"Saved {name} to {file_path}")
                    
        except Exception as e:
            logging.error(f"Error saving to CSV: {e}")
    
    def _load_to_database(self, data: Dict[str, pd.DataFrame]):
        """Load data to database"""
        try:
            # This would load data to analytical tables in the database
            # For now, we'll just log the action
            for name, df in data.items():
                if not df.empty:
                    # In real implementation, you would use df.to_sql()
                    logging.info(f"Would load {name} to database ({len(df)} records)")
                    
        except Exception as e:
            logging.error(f"Error loading to database: {e}")
    
    def _generate_reports(self, data: Dict[str, pd.DataFrame]):
        """Generate analytical reports"""
        try:
            reports = {}
            
            # 1. Summary statistics report
            if 'master_dataset' in data:
                summary_stats = self._generate_summary_statistics(data['master_dataset'])
                reports['summary_statistics'] = summary_stats
            
            # 2. KPI report
            kpi_data = self._calculate_kpis(data)
            reports['kpi_report'] = kpi_data
            
            # 3. Data quality report
            quality_report = self._generate_data_quality_report(data)
            reports['data_quality'] = quality_report
            
            # Save reports
            reports_path = os.path.join(self.config['data_paths']['processed'], 'reports')
            os.makedirs(reports_path, exist_ok=True)
            
            for report_name, report_data in reports.items():
                report_file = os.path.join(reports_path, f'{report_name}.json')
                with open(report_file, 'w') as f:
                    json.dump(report_data, f, indent=2, default=str)
                logging.info(f"Generated {report_name} report")
                
        except Exception as e:
            logging.error(f"Error generating reports: {e}")
    
    def _generate_summary_statistics(self, df: pd.DataFrame) -> Dict:
        """Generate summary statistics"""
        try:
            stats = {
                'total_records': len(df),
                'total_revenue': float(df['TotalAmount'].sum()),
                'avg_order_value': float(df['TotalAmount'].mean()),
                'total_customers': int(df['CustomerID'].nunique()),
                'total_products': int(df['ProductID'].nunique()),
                'date_range': {
                    'start': df['OrderDate'].min().strftime('%Y-%m-%d'),
                    'end': df['OrderDate'].max().strftime('%Y-%m-%d')
                },
                'top_region': df.groupby('Region')['TotalAmount'].sum().idxmax(),
                'top_category': df.groupby('Category')['TotalAmount'].sum().idxmax()
            }
            return stats
        except Exception as e:
            logging.error(f"Error generating summary statistics: {e}")
            return {}
    
    def _calculate_kpis(self, data: Dict[str, pd.DataFrame]) -> Dict:
        """Calculate KPIs"""
        try:
            kpis = {}
            
            if 'sales_cleaned' in data:
                sales_df = data['sales_cleaned']
                kpis.update({
                    'total_revenue': float(sales_df['TotalAmount'].sum()),
                    'total_orders': int(len(sales_df)),
                    'avg_order_value': float(sales_df['TotalAmount'].mean()),
                    'total_quantity': int(sales_df['Quantity'].sum())
                })
            
            if 'customers_cleaned' in data:
                customers_df = data['customers_cleaned']
                kpis.update({
                    'total_customers': int(len(customers_df)),
                    'new_customers_30_days': int((customers_df['CustomerAge'] <= 30).sum())
                })
            
            if 'products_cleaned' in data:
                products_df = data['products_cleaned']
                kpis.update({
                    'total_products': int(len(products_df)),
                    'avg_profit_margin': float(products_df['ProfitMargin'].mean())
                })
            
            return kpis
        except Exception as e:
            logging.error(f"Error calculating KPIs: {e}")
            return {}
    
    def _generate_data_quality_report(self, data: Dict[str, pd.DataFrame]) -> Dict:
        """Generate data quality report"""
        try:
            quality_report = {
                'timestamp': datetime.now().isoformat(),
                'datasets': {}
            }
            
            for name, df in data.items():
                if not df.empty:
                    quality_report['datasets'][name] = {
                        'total_records': len(df),
                        'missing_values': df.isnull().sum().to_dict(),
                        'duplicate_records': df.duplicated().sum(),
                        'data_types': df.dtypes.to_dict()
                    }
            
            return quality_report
        except Exception as e:
            logging.error(f"Error generating data quality report: {e}")
            return {}
    
    def run_pipeline(self):
        """Run the complete data pipeline"""
        try:
            logging.info("Starting data pipeline run")
            self.pipeline_status['status'] = 'running'
            self.pipeline_status['last_run'] = datetime.now().isoformat()
            
            # Step 1: Extract
            raw_data = self.extract_data()
            if not raw_data:
                raise Exception("No data extracted")
            
            # Step 2: Transform
            transformed_data = self.transform_data(raw_data)
            if not transformed_data:
                raise Exception("Data transformation failed")
            
            # Step 3: Load
            self.load_data(transformed_data)
            
            # Update status
            total_records = sum(len(df) for df in transformed_data.values())
            self.pipeline_status['status'] = 'completed'
            self.pipeline_status['records_processed'] = total_records
            self.pipeline_status['errors'] = []
            
            logging.info(f"Pipeline completed successfully. Processed {total_records} records")
            
        except Exception as e:
            self.pipeline_status['status'] = 'failed'
            self.pipeline_status['errors'].append(str(e))
            logging.error(f"Pipeline failed: {e}")
    
    def get_pipeline_status(self) -> Dict:
        """Get current pipeline status"""
        return self.pipeline_status
    
    def schedule_pipeline(self):
        """Schedule pipeline runs"""
        try:
            # Schedule hourly runs
            schedule.every().hour.do(self.run_pipeline)
            
            logging.info("Pipeline scheduled to run hourly")
            
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
                
        except Exception as e:
            logging.error(f"Error scheduling pipeline: {e}")

def main():
    """Main execution function"""
    print("Starting Business Analytics Data Pipeline...")
    
    # Initialize pipeline
    pipeline = DataPipeline()
    
    # Establish database connection
    if pipeline.establish_database_connection():
        print("Database connection established")
    else:
        print("Warning: Database connection failed, proceeding with file-based operations")
    
    # Run pipeline
    pipeline.run_pipeline()
    
    # Display status
    status = pipeline.get_pipeline_status()
    print(f"Pipeline Status: {status['status']}")
    print(f"Records Processed: {status['records_processed']}")
    print(f"Last Run: {status['last_run']}")
    
    if status['errors']:
        print("Errors encountered:")
        for error in status['errors']:
            print(f"  - {error}")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Test Suite for Data Pipeline
Unit tests for the business analytics data pipeline
"""

import unittest
import pandas as pd
import numpy as np
import os
import sys
from unittest.mock import patch, MagicMock

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestDataPipeline(unittest.TestCase):
    """Test cases for data pipeline functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.test_data = {
            'sales': pd.DataFrame({
                'OrderID': [1, 2, 3],
                'CustomerID': ['C001', 'C002', 'C003'],
                'ProductID': ['P001', 'P002', 'P003'],
                'Quantity': [2, 1, 3],
                'UnitPrice': [100.0, 200.0, 50.0],
                'Discount': [0.1, 0.0, 0.05],
                'OrderDate': ['2024-01-01', '2024-01-02', '2024-01-03'],
                'Region': ['North', 'South', 'East']
            }),
            'customers': pd.DataFrame({
                'CustomerID': ['C001', 'C002', 'C003'],
                'CompanyName': ['Company A', 'Company B', 'Company C'],
                'CustomerType': ['Enterprise', 'SME', 'SME'],
                'JoinDate': ['2023-01-01', '2023-06-01', '2023-12-01']
            }),
            'products': pd.DataFrame({
                'ProductID': ['P001', 'P002', 'P003'],
                'ProductName': ['Product A', 'Product B', 'Product C'],
                'Category': ['Electronics', 'Furniture', 'Electronics'],
                'UnitCost': [80.0, 150.0, 40.0],
                'UnitPrice': [100.0, 200.0, 50.0]
            })
        }
    
    def test_data_loading(self):
        """Test data loading functionality"""
        # Test that test data has correct structure
        self.assertIn('sales', self.test_data)
        self.assertIn('customers', self.test_data)
        self.assertIn('products', self.test_data)
        
        # Test sales data structure
        sales_data = self.test_data['sales']
        self.assertEqual(len(sales_data), 3)
        self.assertIn('OrderID', sales_data.columns)
        self.assertIn('TotalAmount', sales_data.columns)  # Should be calculated
    
    def test_data_transformation(self):
        """Test data transformation logic"""
        sales_data = self.test_data['sales'].copy()
        
        # Test TotalAmount calculation
        sales_data['TotalAmount'] = sales_data['Quantity'] * sales_data['UnitPrice'] * (1 - sales_data['Discount'])
        
        expected_total = [180.0, 200.0, 142.5]  # 2*100*0.9, 1*200*1.0, 3*50*0.95
        actual_total = sales_data['TotalAmount'].tolist()
        
        self.assertEqual(actual_total, expected_total)
    
    def test_customer_segmentation(self):
        """Test customer segmentation logic"""
        customers = self.test_data['customers']
        
        # Test customer type distribution
        customer_types = customers['CustomerType'].value_counts()
        self.assertEqual(customer_types['SME'], 2)
        self.assertEqual(customer_types['Enterprise'], 1)
    
    def test_product_analysis(self):
        """Test product analysis calculations"""
        products = self.test_data['products']
        
        # Test profit margin calculation
        products['ProfitMargin'] = ((products['UnitPrice'] - products['UnitCost']) / products['UnitPrice']) * 100
        
        expected_margins = [20.0, 25.0, 20.0]  # (100-80)/100*100, (200-150)/200*100, (50-40)/50*100
        actual_margins = products['ProfitMargin'].tolist()
        
        self.assertEqual(actual_margins, expected_margins)
    
    def test_data_quality_checks(self):
        """Test data quality validation"""
        sales_data = self.test_data['sales']
        
        # Test for missing values
        self.assertFalse(sales_data.isnull().any().any())
        
        # Test for negative values
        self.assertTrue((sales_data['Quantity'] > 0).all())
        self.assertTrue((sales_data['UnitPrice'] > 0).all())
        
        # Test discount range
        self.assertTrue((sales_data['Discount'] >= 0).all())
        self.assertTrue((sales_data['Discount'] <= 1).all())
    
    def test_aggregation_calculations(self):
        """Test data aggregation functions"""
        sales_data = self.test_data['sales'].copy()
        sales_data['TotalAmount'] = sales_data['Quantity'] * sales_data['UnitPrice'] * (1 - sales_data['Discount'])
        
        # Test total revenue calculation
        total_revenue = sales_data['TotalAmount'].sum()
        expected_revenue = 522.5  # 180.0 + 200.0 + 142.5
        
        self.assertEqual(total_revenue, expected_revenue)
        
        # Test average order value
        avg_order_value = sales_data['TotalAmount'].mean()
        expected_avg = 522.5 / 3
        
        self.assertEqual(avg_order_value, expected_avg)
    
    def test_date_processing(self):
        """Test date processing functionality"""
        sales_data = self.test_data['sales'].copy()
        
        # Convert to datetime
        sales_data['OrderDate'] = pd.to_datetime(sales_data['OrderDate'])
        
        # Test date conversion
        self.assertTrue(pd.api.types.is_datetime64_any_dtype(sales_data['OrderDate']))
        
        # Test date range calculation
        min_date = sales_data['OrderDate'].min()
        max_date = sales_data['OrderDate'].max()
        
        self.assertEqual(min_date, pd.Timestamp('2024-01-01'))
        self.assertEqual(max_date, pd.Timestamp('2024-01-03'))
    
    def test_regional_analysis(self):
        """Test regional analysis calculations"""
        sales_data = self.test_data['sales'].copy()
        sales_data['TotalAmount'] = sales_data['Quantity'] * sales_data['UnitPrice'] * (1 - sales_data['Discount'])
        
        # Test regional aggregation
        regional_revenue = sales_data.groupby('Region')['TotalAmount'].sum()
        
        expected_revenue = {
            'North': 180.0,
            'South': 200.0,
            'East': 142.5
        }
        
        for region, expected in expected_revenue.items():
            self.assertEqual(regional_revenue[region], expected)
    
    def test_master_dataset_creation(self):
        """Test master dataset creation"""
        # Simulate master dataset creation
        sales_data = self.test_data['sales'].copy()
        sales_data['TotalAmount'] = sales_data['Quantity'] * sales_data['UnitPrice'] * (1 - sales_data['Discount'])
        
        # Merge with customer data
        master_df = sales_data.merge(self.test_data['customers'], on='CustomerID')
        
        # Test merge result
        self.assertEqual(len(master_df), 3)
        self.assertIn('CompanyName', master_df.columns)
        self.assertIn('CustomerType', master_df.columns)
        self.assertIn('TotalAmount', master_df.columns)

class TestAnalyticsFunctions(unittest.TestCase):
    """Test cases for analytics functions"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.sample_data = pd.DataFrame({
            'CustomerID': ['C001', 'C002', 'C001', 'C003', 'C002'],
            'TotalAmount': [100, 200, 150, 300, 250],
            'OrderDate': pd.to_datetime(['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05'])
        })
    
    def test_customer_lifetime_value(self):
        """Test customer lifetime value calculation"""
        clv = self.sample_data.groupby('CustomerID')['TotalAmount'].sum()
        
        expected_clv = {
            'C001': 250,  # 100 + 150
            'C002': 450,  # 200 + 250
            'C003': 300   # 300
        }
        
        for customer, expected in expected_clv.items():
            self.assertEqual(clv[customer], expected)
    
    def test_purchase_frequency(self):
        """Test purchase frequency calculation"""
        frequency = self.sample_data.groupby('CustomerID').size()
        
        expected_frequency = {
            'C001': 2,
            'C002': 2,
            'C003': 1
        }
        
        for customer, expected in expected_frequency.items():
            self.assertEqual(frequency[customer], expected)
    
    def test_recency_calculation(self):
        """Test customer recency calculation"""
        max_date = self.sample_data['OrderDate'].max()
        recency = self.sample_data.groupby('CustomerID')['OrderDate'].max().apply(lambda x: (max_date - x).days)
        
        expected_recency = {
            'C001': 2,  # 2024-01-05 - 2024-01-03 = 2 days
            'C002': 0,  # 2024-01-05 - 2024-01-05 = 0 days
            'C003': 1   # 2024-01-05 - 2024-01-04 = 1 day
        }
        
        for customer, expected in expected_recency.items():
            self.assertEqual(recency[customer], expected)

class TestDataValidation(unittest.TestCase):
    """Test cases for data validation"""
    
    def test_email_validation(self):
        """Test email format validation"""
        import re
        
        valid_emails = ['test@example.com', 'user.name@domain.co.uk', 'user+tag@example.org']
        invalid_emails = ['invalid-email', '@example.com', 'test@', 'test@.com']
        
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        for email in valid_emails:
            self.assertTrue(re.match(email_pattern, email), f"Valid email {email} failed validation")
        
        for email in invalid_emails:
            self.assertFalse(re.match(email_pattern, email), f"Invalid email {email} passed validation")
    
    def test_phone_validation(self):
        """Test phone number format validation"""
        import re
        
        valid_phones = ['555-123-4567', '(555) 123-4567', '555.123.4567', '5551234567']
        invalid_phones = ['123', '555-1234', 'abc-def-ghij']
        
        phone_pattern = r'^\+?1?-?\.?\s?\(?(\d{3})\)?[-.\s]?(\d{3})[-.\s]?(\d{4})$'
        
        for phone in valid_phones:
            self.assertTrue(re.match(phone_pattern, phone), f"Valid phone {phone} failed validation")
    
    def test_numeric_validation(self):
        """Test numeric data validation"""
        # Test valid numeric values
        valid_values = [100.0, 50, 0, 1000.99]
        
        for value in valid_values:
            self.assertTrue(isinstance(value, (int, float)), f"Valid numeric {value} failed validation")
            self.assertTrue(value >= 0, f"Valid numeric {value} failed non-negative test")
        
        # Test invalid numeric values
        invalid_values = [-100, -50.5]
        
        for value in invalid_values:
            self.assertFalse(value >= 0, f"Invalid numeric {value} passed non-negative test")

def run_tests():
    """Run all test suites"""
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test cases
    test_suite.addTest(unittest.makeSuite(TestDataPipeline))
    test_suite.addTest(unittest.makeSuite(TestAnalyticsFunctions))
    test_suite.addTest(unittest.makeSuite(TestDataValidation))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Return results
    return result.wasSuccessful()

if __name__ == '__main__':
    print("Running Business Analytics Pipeline Tests...")
    print("=" * 50)
    
    success = run_tests()
    
    print("=" * 50)
    if success:
        print("All tests passed successfully! \u2705")
    else:
        print("Some tests failed. Please review the output above. \u274c")
    
    print(f"Test completed at: {pd.Timestamp.now()}")
